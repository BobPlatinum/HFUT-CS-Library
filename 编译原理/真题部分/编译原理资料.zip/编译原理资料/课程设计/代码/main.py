import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter.scrolledtext import ScrolledText


# 自定义一个栈类
class Stack:

    def __init__(self):
        self.__length = 0  # 记录栈内元素数量
        self.__data = []  # 用一个列表来表示栈

    # 进栈
    def push(self, x):
        if x == '':
            messagebox.showinfo("Error", "进栈元素不能为空!")
        else:
            self.__data.append(x)
            self.__length += 1

    # 弹栈
    def pop(self):
        self.__length = len(self.__data)
        if self.__length == 0:
            messagebox.showinfo("Error", "栈已空，不能pop!")
        else:
            self.__length -= 1
            res = self.__data.pop(self.__length)
            return res

    # 栈的所有内容以字符串形式返回
    def toString(self):
        res = ''
        for value in self.__data:
            res += value
        return res

    # 查看栈顶元素
    def top(self):
        self.__length = len(self.__data)
        if self.__length == 0:
            messagebox.showinfo("警告", "栈已空!")
        else:
            print()

# 定义一个类，用于存储文法规则
class Info:
    def __init__(self, left):
        self.left = left  # 左部非终结符
        self.right = []  # 右部产生式
        self.first = set()  # FirstVT集合
        self.last = set()  # LastVT集合

# 全局变量用于存储文法规则的列表
lang = []

# 定义一个全局的算符优先矩阵，初始化为9x9的矩阵，每个元素初始为'n'
mtr = [['n'] * 9 for _ in range(9)]


"""
文法示例
E->E+T
E->E-T
E->T
E->i
T->T*F
T->T/F
T->F
F->(E)
F->i
"""


# 获取输入程序段
def __getProgram(self):
    tmpStr = self.v2.get()
    if tmpStr == '':  # 如果没有输入，就提示错误
        messagebox.showinfo("错误", "请输入程序段！")
    else:  # 有输入,将该字符串返回
        return tmpStr


# 有错提示错误信息
def wrong(self):
    if self.LL1Grammar is None:
        messagebox.showinfo("错误!", "未读取文法！请先选择一个文法！")
        return
    self.__showPredictTable()  # 展示预测分析表
    #self.text.delete('1.0', END)  # 删掉现有的
    stack = Stack()  # 先创建一个栈
    index = 0  # 输入程序段的下标
    step = 0  # 计数步骤
    flag = True  # 分析结束标志
    success = True
    self.program = self.__getProgram()  # 获取输入程序段
    if self.program[-1] != '#':  # 如果输入最后不是#，就给它加上个#,防止用户忘记
        self.program += '#'
    while self.program == '':
        self.program = self.__getProgram()

    stack.push('#')
    stack.push(self.LL1Grammar.beginChar)  # 文法开始符号入栈
    self.text.tag_config('tag', font=('KaiTi', 13))
    template = "{0:^20}{1:<15}{2:>16}{3:^17}{4:^16}\n"  # 设置展示的格式模板
    sContent = stack.toString()
    #self.text.insert(END, template.format(step, sContent, self.program, '', '初始化'), 'tag')
    step += 1
    a = self.program[index]
    while flag:
        X = stack.pop()  # 取栈顶元素
        print('第', step, '步时，X =', X, 'a =', a)
        if X in self.LL1Grammar.tableTerminater:
            if X == a:
                if X == '#' and a == '#':  # 先判断是不是分析完了
                    flag = False
                elif X == '#' and a != '#':
                    messagebox.showinfo("Error", "失败！程序段语法错误！")
                    success = False
                    break
                else:
                    index += 1
                    a = self.program[index]
                    sContent = stack.toString()
                    remain = self.program[index:]
                    gen = ''
                    action = 'GETNEXT(I)'
                    #self.text.insert(END, template.format(step, sContent, remain,
                                                          #gen, action), 'tag')
                    step += 1
            else:
                messagebox.showinfo("Error", "失败！程序段语法错误！")
                success = False
                break

        elif self.LL1Grammar.PredictTable[X][a] != '':
            gen = self.LL1Grammar.PredictTable[X][a]
            pos = self.LL1Grammar.PredictTable[X][a].index('>')
            de = self.LL1Grammar.PredictTable[X][a][pos + 1:]

            if de != 'ε':  # 如果候选不是空字
                tmp = ''
                for i in range(len(de) - 1, -1, -1):  # 把推导倒序入栈
                    stack.push(de[i])
                    tmp += de[i]
                action = 'POP,PUSH(' + tmp + ')'  # 当前步骤的动作
            else:
                action = 'POP'
            remain = self.program[index:]  # 剩余输入串
            sContent = stack.toString()  # 栈内容
            #self.text.insert(END, template.format(step, sContent, remain,
                                                  #gen, action), 'tag')
            step += 1

        else:
            messagebox.showinfo("Error", "失败！程序段语法错误！")
            success = False
            break

    if success:
        messagebox.showinfo("Success!", "分析成功！")


def exitPro(self):
    exit(0)

# 从文件读取文法规则，并解析成内部结构
def get_grammar_from_file(filename):
    """
    从文件中读取文法规则，并解析为内部结构
    """
    lang.clear()  # 清空现有的文法规则
    try:
        with open(filename, 'r') as file:
            lines = file.readlines()
        for line in lines:
            left, rights = line.strip().split('->')
            temp = Info(left)
            temp.right.extend(rights.split('|'))
            lang.append(temp)
    except FileNotFoundError:
        print(f"文件 {filename} 未找到")
    except Exception as e:
        print(f"读取文件时发生错误: {e}")

# 计算文法规则中的FirstVT和LastVT集合
def get_first_last():
    # 首先计算 FirstVT 集合终结符
    for info in lang:
        for right in info.right:
            if right[0] < 'A' or right[0] > 'Z':  # 如果右部第一个符号是终结符，即P->a...
                info.first.add(right[0])
            elif len(right) >= 2 and (right[1] < 'A' or right[1] > 'Z'):  # 如果右部第二个符号是终结符，即P->Qa...
                info.first.add(right[1])

    # 遍历形如P->Q...的产生式，直到不再变化
    sign = 0
    while sign == 0:
        sign = 1  # 假设集合不再变化
        for info in lang:
            for right in info.right:
                if 'A' <= right[0] <= 'Z':  # 如果产生式的右部第一个是非终结符，即P->Q....
                    for k in lang:
                        if k.left == right[0]:  # 找到该非终结符的产生式
                            for ch in k.first:  # 将该非终结符的 FirstVT 集合添加到当前符号的 FirstVT 集合中
                                if ch not in info.first:
                                    info.first.add(ch)
                                    sign = 0  # 如果集合发生变化，继续迭代

    # 首先计算 LastVT 集合终结符
    for info in lang:
        for right in info.right:
            if (right[len(right) - 1] < 'A' or right[len(right) - 1] > 'Z'):  # 如果右部最后一个符号且是终结符,即P->...a
                info.last.add(right[len(right) - 1])
            elif len(right) >= 2 and (
                    right[len(right) - 2] < 'A' or right[len(right) - 2] > 'Z'):  # 如果右部倒数第二个符号是终结符,即P->...aQ
                info.last.add(right[len(right) - 2])

    # 遍历形如P->...Q的产生式，直到不再变化
    sign = 0
    while sign == 0:
        sign = 1  # 假设集合不再变化
        for info in lang:
            for right in info.right:
                if 'A' <= right[len(right) - 1] <= 'Z':  # 如果产生式的右部最后一个字符是非终结符,即P->...Q
                    for k in lang:
                        if k.left == right[len(right) - 1]:  # 找到该非终结符的产生式
                            for ch in k.last:  # 将该非终结符的 LastVT 集合添加到当前符号的 LastVT 集合中
                                if ch not in info.last:
                                    info.last.add(ch)
                                    sign = 0  # 如果集合发生变化，继续迭代


# 计算算符优先矩阵
def get_matrix():

    # 获取所有的终结符
    terminal_symbols = set()
    for info in lang:
        terminal_symbols.update(info.first)
        terminal_symbols.update(info.last)

    terminal_symbols.add('#')

    terminal = ''.join(sorted(terminal_symbols, key=lambda x: '+-*/()i#'.index(x)))
    # terminal = ''.join(terminal_symbols)
    print(terminal)

    #算符优先矩阵
    global mtr
    mtr = [['n'] * (len(terminal) + 1) for _ in range(len(terminal) + 1)]

    # 初始化算符优先矩阵的第一行和第一列
    for i in range(1, len(terminal)+1):
        mtr[i][0] = terminal[i - 1]
        mtr[0][i] = terminal[i - 1]

    # 构造优先表
    for info in lang:
        for right in info.right:
            for i in range(len(right) - 1):
                X_i = right[i]
                X_i1 = right[i + 1]

                # X_i 和 X_i+1 均为终结符
                if X_i in terminal and X_i1 in terminal:
                    mtr[terminal.index(X_i) + 1][terminal.index(X_i1) + 1] = '='

                # i ≤ n - 2 且 X_i 和 X_i+2 都为终结符
                if i <= len(right) - 3 and X_i in terminal and right[i + 2] in terminal and X_i1 not in terminal:
                    mtr[terminal.index(X_i) + 1][terminal.index(right[i + 2]) + 1] = '='

                # X_i 为终结符而 X_i1 为非终结符
                if X_i in terminal and X_i1 not in terminal:
                    # 获取 X_i1 的 first 集合
                    first_set = None
                    for info2 in lang:
                        if info2.left == X_i1:
                            first_set = info2.first
                            break

                    # 设置优先关系
                    if first_set:
                        for a in first_set:
                            mtr[terminal.index(X_i) + 1][terminal.index(a) + 1] = '<'

                # X_i 为非终结符而 X_i1 为终结符
                if X_i not in terminal and X_i1 in terminal:
                    # 获取 X_i 的 last 集合
                    last_set = None
                    for info2 in lang:
                        if info2.left == X_i:
                            last_set = info2.last
                            break

                    # 设置优先关系
                    if last_set:
                        for a in last_set:
                            mtr[terminal.index(a) + 1][terminal.index(X_i1) + 1] = '>'

    # 特殊处理起始和终止符号
    # 获取起始符号
    start_symbol = lang[0].left

    # 获取起始符号的 first 集合
    first_set = None
    for info in lang:
        if info.left == start_symbol:
            first_set = info.first
            break

    # 设置 # 和 first 集合中的符号之间的优先关系为 <
    if first_set:
        for ch in first_set:
            mtr[terminal.index('#') + 1][terminal.index(ch) + 1] = '<'

    # 获取起始符号的 last 集合
    last_set = None
    for info in lang:
        if info.left == start_symbol:
            last_set = info.last
            break

    # 设置 last 集合中的符号和 # 之间的优先关系为 >
    if last_set:
        for ch in last_set:
            mtr[terminal.index(ch) + 1][terminal.index('#') + 1] = '>'

    # 设置 # 和 # 之间的优先关系为 =
    mtr[terminal.index('#') + 1][terminal.index('#') + 1] = '='


# 转换表达式为三元式
def start(expression):
    """
    将算术表达式转换为三元式
    """
    data_stack = []  # 数据栈
    op_stack = ['#']  # 操作符栈，初始化时包含终止符#
    now = 'n'  # 当前操作符
    j = 0  # 用于编号
    output = []  # 存储输出结果

    for i, ch in enumerate(expression):
        sign = 0  # 标记是否为操作符
        if ch.isdigit():  # 处理数字
            number = 0
            while i < len(expression) and expression[i].isdigit():
                number = number * 10 + int(expression[i])
                i += 1
            data_stack.append(str(number))
            i -= 1
        else:
            op_stack.append(ch)
            sign = 1

        if now != 'n' and sign == 1:
            while cmp(now, op_stack[-1]) == 1:  # 如果当前操作符优先级高于栈顶操作符
                j += 1
                avg1 = data_stack.pop()
                avg2 = data_stack.pop()
                num = f"({j})"
                output.append(f"{num}  ( {now},\t{avg2},\t{avg1} )")
                data_stack.append(num)
                op_stack.pop()
                op_stack.pop()
                if op_stack:
                    now = op_stack[-1]
                else:
                    now = 'n'
                op_stack.append(ch)

            if cmp(now, op_stack[-1]) == 0:  # 如果当前操作符优先级等于栈顶操作符
                op_stack.pop()
                op_stack.pop()
                if op_stack:
                    now = op_stack[-1]
                else:
                    break
        else:
            if op_stack:
                now = op_stack[-1]

    while op_stack and op_stack[-1] != '#':  # 处理剩余操作符
        j += 1
        avg1 = data_stack.pop()
        avg2 = data_stack.pop()
        num = f"({j})"
        output.append(f"{num}  ( {now},\t{avg2},\t{avg1} )")
        data_stack.append(num)
        op_stack.pop()
        op_stack.pop()
        if op_stack:
            now = op_stack[-1]

    return output
     # 自定义一个栈类
    class Stack:

        def __init__(self):
            self.__length = 0  # 记录栈内元素数量
            self.__data = []  # 用一个列表来表示栈

        # 进栈
        def push(self, x):
            if x == '':
                messagebox.showinfo("Error", "进栈元素不能为空!")
            else:
                self.__data.append(x)
                self.__length += 1

        # 弹栈
        def pop(self):
            self.__length = len(self.__data)
            if self.__length == 0:
                messagebox.showinfo("Error", "栈已空，不能pop!")
            else:
                self.__length -= 1
                res = self.__data.pop(self.__length)
                return res

        # 栈的所有内容以字符串形式返回
        def toString(self):
            res = ''
            for value in self.__data:
                res += value
            return res

        # 查看栈顶元素
        def top(self):
            self.__length = len(self.__data)
            if self.__length == 0:
                messagebox.showinfo("警告", "栈已空!")
            else:
                print()
    from tkinter.filedialog import askopenfilename
    import tkinter.messagebox as messagebox
    from tkinter.messagebox import showinfo
#    from tkinter import *

    class Stack:

        def __init__(self):
            self.__length = 0  # 记录栈内元素数量
            self.__data = []  # 用一个列表来表示栈

        # 进栈
        def push(self, x):
            if x == '':
                messagebox.showinfo("Error", "进栈元素不能为空!")
            else:
                self.__data.append(x)
                self.__length += 1

        # 弹栈
        def pop(self):
            self.__length = len(self.__data)
            if self.__length == 0:
                messagebox.showinfo("Error", "栈已空，不能pop!")
            else:
                self.__length -= 1
                res = self.__data.pop(self.__length)
                return res

        # 栈的所有内容以字符串形式返回
        def toString(self):
            res = ''
            for value in self.__data:
                if isinstance(value, int) and value >= 10:  # 检查 value 是否为整数且大于等于 10
                    res += f' {value} '
                else:
                    res += str(value)  # 直接添加 value，无论是否为数字
            return res.strip()  # 去掉结果字符串开头和结尾的多余空格

        # 查看栈顶元素
        def top(self):
            self.__length = len(self.__data)
            if self.__length == 0:
                messagebox.showinfo("警告", "栈已空!")
            else:
                return self.__data[self.__length - 1]

    # 文法类
    class LR1Grammar:

        def __init__(self, filename):
            self.grammar = []  # 用列表放文法，每个推导以一个元组表示
            self.grammar2 = {}
            self.Terminater = []
            self.NonTerminater = []
            self.Terminater = []
            self.First = {}
            self.projectSetFamily = []  # 项目集族，用列表存，一个项目集是一个列表
            self.actionTable = {}  # action表
            self.GOTOtable = {}  # goto表
            # 一个元组，（T， n， p） T表示一个产生式编号，n表示右边圆点的位置，p表示展望符，是一个列表
            try:
                f = open(filename, 'r')
                for line in f:
                    nT = line[0]  # 一个推导的非终结符
                    derivation = line[3:].replace('\n', '')  # 右边的产生式
                    self.grammar.append((nT, derivation.replace('蔚', 'ε')))
                f.close()
                print('第一种文法表示法：', self.grammar)
            except:  # 打开文件失败就抛出异常，待GUI处理
                raise IOError('文件打开失败!')

            self.__CalnTandT()  # 求终结符和非终结符
            for nT in self.NonTerminater:
                self.grammar2[nT] = []
            for item in self.grammar:
                self.grammar2[item[0]].append(item[1])
            print('第二种文法表示法:')
            for key in self.grammar2.keys():
                print(key, '->', self.grammar2[key])
            print('非终结符集合：', self.NonTerminater)
            print('终结符集合:', self.Terminater)
            self.allFirst()
            self.calProjectSetFamily()
            self.calActionAndGOTOTable()

        # 计算终结符和非终结符
        def __CalnTandT(self):
            for item in self.grammar:
                if item[0] not in self.NonTerminater:
                    self.NonTerminater.append(item[0])
            for item in self.grammar:
                for subDe in item[1]:
                    if subDe not in self.NonTerminater \
                            and subDe not in self.Terminater:
                        self.Terminater.append(subDe)

        # 求first集
        def allFirst(self):
            for T in self.Terminater:  # 终结符的first集就是他自己
                self.First[T] = [T]
            for nT in self.NonTerminater:  # 先循环给非终结符的first集一个空列表
                self.First[nT] = []
            if 'ε' in self.First.keys():  # 空字不是终结符，得去掉
                self.First.pop('ε')
            for nT in self.NonTerminater:
                derivation = self.grammar2[nT]
                if 'ε' in derivation:  # 空字在推导中，就把空字也加入它的first集中
                    self.First[nT].append('ε')
            for item in self.grammar:
                derivation = item[1]
                if derivation == 'ε':
                    continue
                if derivation[0] in self.Terminater:
                    self.First[item[0]].append(derivation[0])
            # 再倒着来，从最后一个文法开始往前推
            for i in range(len(self.grammar) - 1, -1, -1):
                if self.grammar[i][1] == 'ε':
                    continue
                de = self.grammar[i][1]
                allHaveNone = True
                for subDe in de:
                    if subDe in self.NonTerminater:  # 如果一个产生式右边第一个字符是非终结符
                        for f in self.First[subDe]:  # 就把这个非终结符的first集给推出它的非终结符
                            if f not in self.First[self.grammar[i][0]]:
                                self.First[self.grammar[i][0]].append(f)
                        if 'ε' not in self.First[subDe]:
                            allHaveNone = False
                            break
                    elif subDe in self.Terminater:  # 产生式中有一个终结符，就退出for
                        break
                # for正常执行完，说明一个产生式右边全是非终结符
                else:
                    if allHaveNone:  # 再看这个全部是非终结符的标记是否为真
                        self.First[self.grammar[i][0]].append('ε')

        # 求一个符号串X的first集
        def first(self, X):
            if self.First == {}:
                print('请先调用allFirst方法求出所有first集!')
                return
            # 符号串，所以默认没有空字，就不用考虑空字
            res = []
            for subX in X:
                if subX in self.NonTerminater:  # 如果字符是非终结符
                    res += self.First[subX]
                    if 'ε' not in self.First[subX]:  # 如果这个非终结符的first集没有空字，就退出
                        break  # 有空字，就能继续往后看
                elif subX in self.Terminater and subX not in res:  # 终结符就加入结果列表并退出循环
                    res.append(subX)
                    break
            return res

        # 求文法的项目集族
        def calProjectSetFamily(self):
            # 元组（T，n，p）
            T = 0  # 第一个产生式标号为0
            n = 1  # 第一个项目右边圆点位置是第一个
            p = '#'  # 第一个项目的展望符肯定是#
            I0 = self.__closure([(T, n, p)])  # 先求第一个项目的闭包
            self.projectSetFamily.append(I0)  # 加入项目集族
            allChar = self.NonTerminater + self.Terminater  # 文法的所有符号
            allChar.remove(self.NonTerminater[0])  # 去掉拓广文法的最开始符
            for projectset in self.projectSetFamily:  # 对每个项目集和每个文法，求
                for char in allChar:
                    J = self.__J(projectset, char)
                    if not J:
                        continue
                    tmp = self.__closure(J)
                    if tmp not in self.projectSetFamily:
                        self.projectSetFamily.append(tmp)
            # 输出所有项目集
            for i in range(len(self.projectSetFamily)):
                print('项目集', i, ':')
                for item in self.projectSetFamily[i]:
                    print(item)

        # 求一个项目的闭包
        def __closure(self, project):
            # project是一个项目，是一个三个元素的元组
            res = project
            for item in project:
                T = item[0]  # 产生式编号
                n = item[1]  # 右边圆点位置，用来索引圆点右边那个符号
                p = item[2]  # 当前项目item的展望符
                sizeOfProduct = len(self.grammar[T][1])
                if n == sizeOfProduct + 1:  # 如果圆点的位置在产生式的最后，那么就跳过当前这个产生式，看下一个
                    continue
                X = self.grammar[T][1][n - 1]  # 索引圆点右边那个符号
                if X in self.NonTerminater:  # 如果X是非终结符
                    # 先求这个X后面的符号连接上展望符的first集
                    if n == sizeOfProduct:
                        first = p
                    else:
                        # 再求展望符
                        first = self.first(self.grammar[T][1][n] + p)

                    prods = []  # 求X作为产生式左边的推导的编号
                    for i in range(len(self.grammar)):
                        if self.grammar[i][0] == X:
                            prods.append(i)
                    # 把不在原项目集中的项目加到当前项目集中
                    for prod in prods:
                        for f in first:
                            if (prod, 1, f) not in res:
                                res.append((prod, 1, f))
            # else就是终结符，就不管

            return res

        # 求一个项目集J
        def __J(self, I, X):
            res = []
            for project in I:
                T = project[0]  # 项目的产生式的标号
                n = project[1]  # 右边圆点位置
                p = project[2]  # 项目的展望符
                product = self.grammar[T][1]  # 产生式右边的字符串
                # 遍历这个推导，由于字符串的特性，因此这里用下标的方式来遍历
                for i in range(len(product)):
                    if product[i] == X:  # 第i个字符是X，
                        if i == n - 1:  # 如果它在圆点右边，就把它加入res
                            res.append((T, n + 1, p))
            return res

        # 定义函数,返回一个项目集在项目集族中的标号
        def __GO(self, I, X):
            J = self.__J(self.projectSetFamily[I], X)
            closureJ = self.__closure(J)
            res = -1
            for i in range(len(self.projectSetFamily)):
                if closureJ == self.projectSetFamily[i]:
                    res = i
                    break

            return res

        # 求action表	和goto表,
        def calActionAndGOTOTable(self):
            statusNum = len(self.projectSetFamily)  # 状态数
            Terminater = self.Terminater.copy()
            Terminater.append('#')

            # 先把所有项目集放到一个列表里
            allProject = []
            for projectSet in self.projectSetFamily:
                allProject += [x for x in projectSet if x not in allProject]
            for k in range(statusNum):  # 遍历每个项目集
                self.actionTable[k] = {}  # 初始，给每个状态一个空字典，这样就能通过双重字典来实现两个字符索引
                self.GOTOtable[k] = {}
                for T in self.Terminater:
                    self.actionTable[k][T] = ''  # 先给表中每个元素赋值空字
                self.actionTable[k]['#'] = ''  # 把’#‘也给加上
                for NT in self.NonTerminater:
                    self.GOTOtable[k][NT] = ''

            for project in allProject:  # 遍历每个项目
                T = project[0]  # 项目的产生式的标号
                n = project[1]  # 右边圆点位置
                p = project[2]  # 项目的展望符
                sizeOfProduct = len(self.grammar[T][1])
                for k in range(statusNum):
                    if project not in self.projectSetFamily[k]:  # 某项目不在某项目集，continue
                        continue
                    # 执行到这说明该项目在某项目集中
                    if (0, 2, '#') == project:  # 先判断第三个规则，符合的话直接退出当前循环
                        self.actionTable[k]['#'] = 'acc'
                    else:
                        if n == sizeOfProduct + 1:  # 第二个规则，因为如果先判断第一个的话要用到n-1，而n-1可能会越界，所以先判第二
                            self.actionTable[k][p] = 'r' + str(T)
                        else:
                            a = self.grammar[T][1][n - 1]  # 索引圆点右边那个符号,判断第一个规则
                            if a in Terminater:
                                j = self.__GO(k, a)
                                self.actionTable[k][a] = 's' + str(j) if j != -1 else ''
                            A = self.grammar[T][0]  # 第四个规则
                            j = self.__GO(k, A)
                            self.GOTOtable[k][A] = j if j != -1 else ''
    class LR1GUI:

        # 初始化，包括窗体，按钮等,要用到文法，所以给一个文法参数
        def __init__(self):
            self.window = Tk()  # 创建一个窗口

            self.window.title('LR(1)分析 -- 许航睿')  # 标题
            self.window.geometry('800x600')  # 设置窗口大小
            self.window.configure(bg='#ffffff')  # 设置窗口背景颜色

            self.LR1Grammar = None  # 文法对象先初始化为None，待打开文件后再初始化
            self.program = ""  # 待分析的程序段
            self.grammarLabels = []  # 记录展示的文法和对应的first和follow的标签
            self.R1analysisTableLabels = []  # 记录预测分析表的标签
            self.analysisTableLabels = []  # 记录分析结果的表格标签

            # 设置滚动条和画布
            outer_frame = Frame(self.window)
            outer_frame.pack(fill=BOTH, expand=True)

            canvas = Canvas(outer_frame, bg='#ffffff')
            scrollbar = Scrollbar(outer_frame, orient="vertical", command=canvas.yview)
            canvas.configure(yscrollcommand=scrollbar.set)

            scrollbar.pack(side="right", fill="y")
            canvas.pack(side="left", fill="both", expand=True)

            inner_frame = Frame(canvas, bg='#ffffff')
            canvas.create_window((400, 0), window=inner_frame, anchor='center')
            inner_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
            inner_frame.bind_all("<MouseWheel>", lambda event: self._on_mousewheel(event, canvas))

            self.inner_frame = inner_frame  # 保存内部框架的引用

            # 设置布局
            frame = Frame(inner_frame, bg='#ffffff')  # 这个框架放介绍文字
            frame1 = Frame(inner_frame, bg='#ffffff')  # 这个框架放提示输入文法
            frame2 = Frame(inner_frame, bg='#ffffff')  # 这个框架放读取文法程序
            self.frame3 = Frame(inner_frame, bg='#ffffff')  # 这个框架放文法，first集，follow集
            self.frame6 = Frame(inner_frame, bg='#ffffff')  # 放预测分析表
            self.frame5 = Frame(inner_frame, bg='#ffffff')  # 新增行：放分析结果

            frame.pack(pady=10)
            frame1.pack()
            frame2.pack(pady=10)
            self.frame3.pack()
            self.frame6.pack(pady=10)
            self.frame5.pack()  # 确保结果框架也被包装和显示

            self.v2 = StringVar()  # 获取输入程序段的文本框
            self.btShowFirstFollow = Button(frame1, text='生成First集', command=self.__showGrammar,
                                            font=('KaiTi', 13), bg='#2196F3', fg='white', width=20)
            self.btShowPredictTable = Button(frame1, text='生成LR(1)分析表', command=self.showLR1analysisTable,
                                             font=('KaiTi', 13), bg='#FF9800', fg='white', width=18)
            self.btShowFirstFollow.grid(row=1, column=3, padx=10)
            self.btShowPredictTable.grid(row=1, column=4, padx=10)

            # 添加标签，输入框，按钮等组件
            welcome = Label(frame, text='LR(1)文法分析器--by 许航睿', font=('KaiTi', 20, 'bold'), anchor='center',
                            bg='#ffffff')
            btChoose = Button(frame1, text='打开', command=self.__getFileByInteract, font=('KaiTi', 13), bg='#4CAF50',
                              width=18, fg='white')
            promptLable = Label(frame2, text='请输入一个程序段:', font=('KaiTi', 14), bg='#ffffff')
            entryProgram = Entry(frame2, textvariable=self.v2, justify=LEFT, width=30, font=('KaiTi', 14))
            analysisButton = Button(frame2, text='执行分析', command=self.analysis, font=('KaiTi', 12), bg='#4CAF50',
                                    fg='white')

            welcome.grid()
            btChoose.grid(row=1, column=2)
            promptLable.grid(row=2, column=1)
            entryProgram.grid(row=2, column=2)
            analysisButton.grid(row=2, column=3)

            self.window.mainloop()  # 事件循环

        def _on_mousewheel(self, event, canvas):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        # 交互式选择文法文件
        def __getFileByInteract(self):
            fileName = askopenfilename()
            print(fileName)
            if fileName:
                self.LR1Grammar = LR1Grammar(fileName)  # 初始化文法对象
                messagebox.showinfo("提示", "文件已载入，可以生成First集和分析表。")

                # 清空之前的分析结果和标签
                for label in self.grammarLabels:
                    label.destroy()
                self.grammarLabels = []  # 清空保存标签的列表

                for label in self.R1analysisTableLabels:
                    label.destroy()
                self.R1analysisTableLabels = []  # 清空保存预测分析表标签的列表
                # 清空之后立即在原地刷新区域（示例）
                self.refreshGrammarArea()
                self.refreshPredictTableArea()
                self.refreshAnalysisArea()

        def refreshGrammarArea(self):
            for label in self.grammarLabels:
                label.destroy()
            self.grammarLabels = []
            # 可以在这里添加恢复到初始状态的文本或标签
            label = Label(self.frame3, text="等待生成First集...", font=('KaiTi', 12), bg='#ffffff')
            label.pack()
            self.grammarLabels.append(label)

        def refreshPredictTableArea(self):
            for label in self.R1analysisTableLabels:
                label.destroy()
            self.R1analysisTableLabels = []
            # 可以在这里添加恢复到初始状态的文本或标签
            label = Label(self.frame6, text="等待生成LR(1)分析表...", font=('KaiTi', 12), bg='#ffffff')
            label.pack()
            self.R1analysisTableLabels.append(label)

        def refreshAnalysisArea(self):
            # 先清空之前的标签
            for label in self.analysisTableLabels:
                label.destroy()
            self.analysisTableLabels = []

            # 添加恢复到初始状态的文本或标签
            label = Label(self.frame5, text="等待生成分析结果...", font=('KaiTi', 12), bg='#ffffff')
            label.pack()
            self.analysisTableLabels.append(label)

        # 在GUI上展示文法和文法的first集
        def __showGrammar(self):
            if not self.LR1Grammar:  # 检查是否已经加载了文法文件
                showinfo("错误", "请先选择一个文法文件！")
                return
            if self.grammarLabels:  # 每次展示前先把前面一个文法的所有标签删掉
                for label in self.grammarLabels:
                    label.destroy()
            self.grammarLabels = []
            r = 1

            # 添加表头
            l = Label(self.frame3, text='所选文法如下：', font=('KaiTi', 14), justify=LEFT, bg='#ffffff', anchor='w')
            l.grid(row=r, column=1, padx=5, pady=5, sticky=W)
            self.grammarLabels.append(l)

            l = Label(self.frame3, text='FIRST集：', font=('KaiTi', 14), justify=LEFT, bg='#ffffff', anchor='w')
            l.grid(row=r, column=2, padx=5, pady=5, sticky=W)
            self.grammarLabels.append(l)
            r = 2

            for key in self.LR1Grammar.grammar2.keys():
                col = 1
                string = key + '->'  # 先展示文法
                tmp = self.LR1Grammar.grammar2[key]
                if '' in tmp:  # 展示的时候把空字''替换为'ε'
                    tmp[tmp.index('')] = 'ε'
                string += '|'.join(tmp)
                l = Label(self.frame3, text=string, font=('KaiTi', 12), width=40, justify=LEFT, bg='#ffffff', anchor=W)
                l.grid(row=r, column=col, padx=5, pady=5, sticky=W)
                self.grammarLabels.append(l)

                col = 2
                string = 'FIRST(' + key + ')={'  # 再展示first
                tmp = self.LR1Grammar.First[key]
                if '' in tmp:
                    tmp[tmp.index('')] = 'ε'
                string += ','.join(tmp) + '}'
                l = Label(self.frame3, text=string, font=('KaiTi', 12), width=25, justify=LEFT, bg='#ffffff', anchor=W)
                l.grid(row=r, column=col, padx=5, pady=5, sticky=W)
                self.grammarLabels.append(l)

                r += 1

        # 获取输入程序段
        def __getProgram(self):
            tmpStr = self.v2.get()
            if tmpStr == '':  # 如果没有输入，就提示错误
                messagebox.showinfo("错误", "请输入程序段！")
            else:  # 有输入,将该字符串返回
                return tmpStr

        # 展示分析表
        def showLR1analysisTable(self):
            if not self.LR1Grammar:  # 检查是否已经加载了文法文件
                messagebox.showinfo("错误", "请先选择一个文法文件！")
                return
            if self.R1analysisTableLabels:  # 每次先把前面的文法的分析表删除掉
                for label in self.R1analysisTableLabels:
                    label.destroy()
            self.R1analysisTableLabels = []

            # 表头
            r, col = 1, 1
            l = Label(self.frame6, text='LR（1）分析表', font=('KaiTi', 16, 'bold'), bg='#f0f0f0', borderwidth=2,
                      relief='solid')
            l.grid(row=r, column=col,
                   columnspan=len(self.LR1Grammar.Terminater) + len(self.LR1Grammar.NonTerminater) + 2,
                   sticky='ew')
            self.R1analysisTableLabels.append(l)

            # 状态标签
            r += 1
            col = 1
            l = Label(self.frame6, text='状态', width=8, background='#d3d3d3', font=('Arial', 10, 'bold'),
                      borderwidth=2,
                      relief='ridge')
            l.grid(row=r, column=col, rowspan=2, sticky='nsew')
            self.R1analysisTableLabels.append(l)
            col += 1

            # ACTION（动作）标签
            l = Label(self.frame6, text='ACTION（动作）', width=8 * len(self.LR1Grammar.Terminater), background='#d3d3d3',
                      font=('Arial', 10, 'bold'), borderwidth=2, relief='ridge')
            l.grid(row=r, column=col, columnspan=len(self.LR1Grammar.Terminater) + 1, sticky='nsew')
            self.R1analysisTableLabels.append(l)
            col += len(self.LR1Grammar.Terminater) + 1

            # GOTO（转换）标签
            l = Label(self.frame6, text='GOTO（转换）', width=8 * len(self.LR1Grammar.NonTerminater),
                      background='#d3d3d3',
                      font=('Arial', 10, 'bold'), borderwidth=2, relief='ridge')
            l.grid(row=r, column=col, columnspan=len(self.LR1Grammar.NonTerminater), sticky='nsew')
            self.R1analysisTableLabels.append(l)

            # 终结符表头
            r += 1
            col = 2
            for T in self.LR1Grammar.Terminater:
                l = Label(self.frame6, text=T, width=8, background='#f0f0f0', borderwidth=2, relief='ridge',
                          font=('Arial', 10))
                l.grid(row=r, column=col, sticky='nsew')
                self.R1analysisTableLabels.append(l)
                col += 1

            # 加上结束符 #
            l = Label(self.frame6, text='#', width=8, background='#f0f0f0', borderwidth=2, relief='ridge',
                      font=('Arial', 10))
            l.grid(row=r, column=col, sticky='nsew')
            self.R1analysisTableLabels.append(l)
            col += 1

            # 非终结符表头
            for nT in self.LR1Grammar.NonTerminater:
                l = Label(self.frame6, text=nT, width=8, background='#f0f0f0', borderwidth=2, relief='ridge',
                          font=('Arial', 10))
                l.grid(row=r, column=col, sticky='nsew')
                self.R1analysisTableLabels.append(l)
                col += 1

            # 每个状态及其对应的分析结果
            r += 1
            for i in range(len(self.LR1Grammar.projectSetFamily)):
                col = 1
                l = Label(self.frame6, text=i, width=8, background='#e6e6e6', borderwidth=2, relief='ridge',
                          font=('Arial', 10))
                l.grid(row=r, column=col, sticky='nsew')
                self.R1analysisTableLabels.append(l)
                col += 1
                for T in self.LR1Grammar.Terminater:
                    action_text = self.LR1Grammar.actionTable[i].get(T, '')
                    l = Label(self.frame6, text=action_text, width=8, background='#ffffff', borderwidth=2,
                              relief='ridge',
                              font=('Arial', 10))
                    l.grid(row=r, column=col, sticky='nsew')
                    self.R1analysisTableLabels.append(l)
                    col += 1
                l = Label(self.frame6, text=self.LR1Grammar.actionTable[i].get('#', ''), width=8, background='#ffffff',
                          borderwidth=2, relief='ridge', font=('Arial', 10))
                l.grid(row=r, column=col, sticky='nsew')
                self.R1analysisTableLabels.append(l)
                col += 1
                for nT in self.LR1Grammar.NonTerminater:
                    goto_text = self.LR1Grammar.GOTOtable[i].get(nT, '')
                    l = Label(self.frame6, text=goto_text, width=8, background='#ffffff', borderwidth=2, relief='ridge',
                              font=('Arial', 10))
                    l.grid(row=r, column=col, sticky='nsew')
                    self.R1analysisTableLabels.append(l)
                    col += 1
                r += 1

        # 执行分析,有错提示错误信息
        def analysis(self):
            if self.LR1Grammar is None:
                messagebox.showinfo("错误!", "未读取文法！请先选择一个文法！")
                return
            if self.analysisTableLabels:  # 每次先把前面的文法的分析表删除掉
                for label in self.analysisTableLabels:
                    label.destroy()

            self.analysisTableLabels = []
            r = 1
            step_col_width = 6  # 步骤列宽度
            state_col_width = 15  # 状态和符号列宽度
            input_col_width = 12  # 输入串列宽度
            action_col_width = 42  # 动作列宽度

            # 创建标题
            title = Label(self.frame5, text="程序段分析结果", font=('KaiTi', 14), bg='#ffffff')
            title.grid(row=r, column=1, columnspan=5, sticky='nsew')
            self.analysisTableLabels.append(title)

            r += 1

            # 创建表头
            headers = ["步骤", "状态栈", "符号栈", "输入串", "动作"]
            col_widths = [step_col_width, state_col_width, state_col_width, input_col_width, action_col_width]
            for i, (header, width) in enumerate(zip(headers, col_widths)):
                label = Label(self.frame5, text=header, font=('KaiTi', 12), bg='#f0f0ff', width=width, relief='ridge')
                label.grid(row=r, column=i + 1, sticky='nsew')
                self.analysisTableLabels.append(label)

            r += 1
            step = 0  # 分析步数
            statusStack = Stack()  # 状态栈
            charStack = Stack()  # 符号栈
            index = 0  # 输入程序段的下标
            statusStack.push(0)  # 一开始先把0状态入栈
            charStack.push('#')  # '#'入栈
            self.program = self.__getProgram()  # 获取待分析程序段
            while self.program == '':
                self.program = self.__getProgram()
            if self.program[-1] != '#':  # 如果输入最后不是#，就给它加上个#, 防止用户忘记
                self.program += '#'

            actionTable = self.LR1Grammar.actionTable
            GOTOtable = self.LR1Grammar.GOTOtable
            success = True

            while True:
                a = self.program[index]
                i = statusStack.top()
                action = actionTable[i][a]
                charStContent = charStack.toString()
                statusStContent = statusStack.toString()
                remain = self.program[index:]
                print(f'第{step}步，a = {a}, i = {i}', end='')
                print(f'action = {action}')

                if action == 'acc':  # 接受
                    print(f'接受，index = {index}')
                    step_data = [str(step), statusStContent, charStContent, remain, '接受，分析成功']
                    for j, (data, width) in enumerate(zip(step_data, col_widths)):
                        label = Label(self.frame5, text=data, font=('KaiTi', 12), bg='#f0f0ff', width=width,
                                      relief='ridge', anchor='w')
                        label.grid(row=r, column=j + 1, sticky='nsew')
                        self.analysisTableLabels.append(label)
                    break
                elif action[0] == 's':  # 移进
                    j = int(action[1:])  # 要移进的状态
                    mess = f'action({i}, {a}) = {action}, 状态 {j} 入栈'
                    step_data = [str(step), statusStContent, charStContent, remain, mess]
                    for k, (data, width) in enumerate(zip(step_data, col_widths)):
                        label = Label(self.frame5, text=data, font=('KaiTi', 12), bg='#f0f0ff', width=width,
                                      relief='ridge', anchor='w')
                        label.grid(row=r, column=k + 1, sticky='nsew')
                        self.analysisTableLabels.append(label)
                    statusStack.push(j)
                    charStack.push(a)
                    index += 1  # 输入串指针后移
                    step += 1
                elif action[0] == 'r':  # 规约
                    # 先从状态栈弹出n个状态，n为规约产生式的长度
                    prodNum = int(action[1:])
                    prod = self.LR1Grammar.grammar[prodNum][1]
                    prodLen = len(prod)
                    for _ in range(prodLen):  # 把n个字符从状态栈和符号栈弹出
                        statusStack.pop()
                        charStack.pop()
                    # 将用到的规约式的非终结符入栈
                    A = self.LR1Grammar.grammar[prodNum][0]
                    charStack.push(A)
                    i = statusStack.top()
                    go = GOTOtable[i][A]
                    statusStack.push(go)  # 新状态入栈
                    mess = f'{action}: {self.LR1Grammar.grammar[prodNum][0]} -> {prod}, 规约, GOTO({i}, {A}) = {go}'
                    step_data = [str(step), statusStContent, charStContent, remain, mess]
                    for k, (data, width) in enumerate(zip(step_data, col_widths)):
                        label = Label(self.frame5, text=data, font=('KaiTi', 12), bg='#f0f0ff', width=width,
                                      relief='ridge', anchor='w')
                        label.grid(row=r, column=k + 1, sticky='nsew')
                        self.analysisTableLabels.append(label)
                    step += 1
                else:
                    messagebox.showinfo('错误！', '输入程序段非法！')
                    success = False
                    break
                r += 1

            if success:
                messagebox.showinfo('提示', '分析成功!')
            else:
                messagebox.showinfo('错误', '分析失败！')

        def exitPro(self):
            exit(0)


    def __first(self):
        for nT in self.NonTerminater:  # 先赋值一个空列表
            self.First[nT] = []
        # 后面要用到递归，所以分开两个循环
        for T in self.Terminater:  # 终结符的first集就是他自己
            self.First[T] = [T]
        for nT in self.NonTerminater:
            self.__subFirst(nT)

    # 求first集的递归子方法
    def __subFirst(self, X):
        tmpSize = len(self.First[X])  # 求之前的大小
        if X in self.Terminater and X not in self.First[X]:  # 如果X在终结符里， 则X属于first(X)
            self.First[X].append(X)
        else:  # else X就不是终结符，对X的每个推导，依次判断推导的字符是什么
            for derivation in self.grammar[X]:
                # 先判断是不是空字，是空字就加入
                if derivation == '':
                    if '' not in self.First[X]:
                        self.First[X].append('')
                # 再判断每个推导的第一个字符是不是终结符，是则加入
                elif derivation[0] in self.Terminater:
                    if derivation[0] not in self.First[X]:
                        self.First[X].append(derivation[0])
                else:
                    # else，就全是非终结符，
                    # 再遍历他们，递归的求每个字符的first集
                    for subDe in derivation:
                        self.__subFirst(subDe)
            # 对每个推导都处理完后，把每个推导的first集放到first（x）中
            for derivation in self.grammar[X]:
                if derivation == '' or derivation[0] in self.Terminater:
                    continue
                # 找每个推导串中第一个不能推导出空字的非终结符
                location = -1
                for i in range(len(derivation)):
                    if '' not in self.grammar[derivation[i]]:
                        location = i
                        break
                if location == -1:  # 如果都能推出空字,
                    # 就把所有推导式子字符的first集加入first(X)
                    for subDe in derivation:
                        for ele in self.First[subDe]:
                            if ele not in self.First[X]:
                                self.First[X].append(ele)
                else:  # 否则从第一个不能推导出空字的非终结符开始
                    for i in range(location + 1):
                        # print('将', derivation[i], '的first集加入', X, '的')
                        for ele in self.First[derivation[i]]:
                            if ele != '' and ele not in self.First[X]:
                                self.First[X].append(ele)

        if len(self.First[X]) == tmpSize:  # 长度不变就返回
            return

    # 求一个文法的一个非终结符的follow集，定义成私有方法，只在创建对象时由初始化函数调用
    def __follow(self):
        for nT in self.NonTerminater:
            self.Follow[nT] = []  # 同样赋值一个空列表
        self.Follow[self.NonTerminater[0]].append('#')  # 将’#‘加入开始符号的follow集中
        for nT in self.NonTerminater:
            self.__subFollow(nT)

    # 求follow集的递归子程序
    def __subFollow(self, X):
        for key in self.grammar.keys():  # 遍历每个推导式子
            for derivation in self.grammar[key]:  # 对每个推导式，遍历子字符
                lenOfDe = len(derivation)
                for i in range(lenOfDe):
                    if X == derivation[i]:  # 在产生式中找到要求的
                        if i == lenOfDe - 1:  # 如果他在推导式的最后一个字符
                            for f in self.Follow[key]:
                                if f not in self.Follow[X] and f != '':
                                    self.Follow[X].append(f)
                        # 否则如果他后面跟的不是非终结符，就把这个符号放到follow(X)里
                        elif derivation[i + 1] not in self.NonTerminater:
                            # print(X, '后面是', derivation[i + 1])
                            if derivation[i + 1] not in self.Follow[X]:
                                self.Follow[X].append(derivation[i + 1])
                        # 如果后面跟了一个非终结符Y
                        elif derivation[i + 1] in self.NonTerminater:
                            # 就把first(Y)给它
                            for f in self.First[derivation[i + 1]]:
                                if f not in self.Follow[X] and f != '':
                                    self.Follow[X].append(f)
                            # 再额外判断空字是否属于first(Y)
                            if '' in self.First[derivation[i + 1]]:
                                for f in self.Follow[key]:
                                    if f not in self.Follow[X] and f != '':
                                        self.Follow[X].append(f)


# 比较操作符优先级，返回1表示a>b，0表示a=b，-1表示a<b，2表示错误
def cmp(a, b):
    """
    比较两个操作符的优先级
    """
    for i in range(1, 9):
        if mtr[i][0] == a:
            for j in range(1, 9):
                if mtr[0][j] == b:
                    if mtr[i][j] == '>':
                        return 1
                    elif mtr[i][j] == '=':
                        return 0
                    elif mtr[i][j] == '<':
                        return -1
    return 2

# 定义主界面类
class ExpressionConverterApp:
    def __init__(self, root):


        self.root = root
        self.root.title("算术表达式转换成三元式")

        # 使用一个框架来添加滚动条
        main_frame = tk.Frame(root)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # 添加滚动条
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(
                scrollregion=canvas.bbox("all")
            )
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="n")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # 上部信息
        tk.Label(scrollable_frame, text="编译原理课程设计：算术表达式转换成三元式", font=("宋体", 18)).pack(pady=10)
        tk.Label(scrollable_frame, text="By：许航睿", font=("宋体", 14)).pack(pady=5)

        # 显示文法规则的文本框
        self.grammar_display = ScrolledText(scrollable_frame, width=80, height=10, font=("宋体", 12), state=tk.DISABLED)
        self.grammar_display.pack(pady=10)

        # 文件读入文法按钮
        self.load_grammar_button = tk.Button(scrollable_frame, text="文件读入文法", command=self.load_grammar,
                                             font=("宋体", 12))
        self.load_grammar_button.pack(pady=5)

        # 显示FirstVT和LastVT集合的文本框
        self.first_last_display = ScrolledText(scrollable_frame, width=80, height=10, font=("宋体", 12),
                                               state=tk.DISABLED)
        self.first_last_display.pack(pady=10)

        # 展示FirstVT和LastVT按钮
        self.first_last_button = tk.Button(scrollable_frame, text="展示FirstVT和LastVT", command=self.show_first_last,
                                           font=("宋体", 12))
        self.first_last_button.pack(pady=5)

        # 显示算符优先矩阵的文本框
        self.matrix_display = ScrolledText(scrollable_frame, width=80, height=10, font=("宋体", 12), state=tk.DISABLED)
        self.matrix_display.pack(pady=10)

        # 展示算符优先矩阵按钮
        self.matrix_button = tk.Button(scrollable_frame, text="展示算符优先矩阵", command=self.show_matrix,
                                       font=("宋体", 12))
        self.matrix_button.pack(pady=5)

        # 输入算术表达式的标签和输入框
        tk.Label(scrollable_frame, text="输入算术表达式：", font=("宋体", 14)).pack(pady=10)
        self.expression_entry = tk.Entry(scrollable_frame, font=("宋体", 14), width=50)
        self.expression_entry.pack(pady=5)

        # 显示转换结果的文本框
        self.result_display = ScrolledText(scrollable_frame, width=80, height=10, font=("宋体", 12), state=tk.DISABLED)
        self.result_display.pack(pady=10)

        # 转换成三元式按钮
        self.convert_button = tk.Button(scrollable_frame, text="转换成三元式", command=self.convert_expression,
                                        font=("宋体", 12))
        self.convert_button.pack(pady=5)

        # 保存结果到文件按钮
        self.save_button = tk.Button(scrollable_frame, text="保存结果到文件", command=self.save_results,
                                     font=("宋体", 12))
        self.save_button.pack(pady=10)

        # 绑定鼠标滚轮事件
        self.bind_scroll_events(canvas)

    # 绑定鼠标滚轮事件
    def bind_scroll_events(self, canvas):
        """
        绑定鼠标滚轮事件
        """
        def on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", on_mousewheel)

    # 加载文法文件
    def load_grammar(self):
        """
        从文件中加载文法规则
        """
        filename = filedialog.askopenfilename(title="选择文法文件", filetypes=[("Text files", "*.txt")])
        if filename:
            get_grammar_from_file(filename)
            self.grammar_display.config(state=tk.NORMAL)
            self.grammar_display.delete(1.0, tk.END)
            for info in lang:
                for right in info.right:
                    self.grammar_display.insert(tk.END, f"{info.left} --> {right}\n")
            self.grammar_display.config(state=tk.DISABLED)

    # 展示FirstVT和LastVT集合
    def show_first_last(self):
        """
        计算并展示FirstVT和LastVT集合
        """
        get_first_last()
        first_vt_dict = {}
        last_vt_dict = {}

        for info in lang:
            if info.left not in first_vt_dict:
                first_vt_dict[info.left] = info.first
            else:
                first_vt_dict[info.left] |= info.first

            if info.left not in last_vt_dict:
                last_vt_dict[info.left] = info.last
            else:
                last_vt_dict[info.left] |= info.last

        self.first_last_display.config(state=tk.NORMAL)
        self.first_last_display.delete(1.0, tk.END)

        self.first_last_display.insert(tk.END, "FirstVT:\n")
        for key, value in first_vt_dict.items():
            first_vt = '  '.join(value)
            self.first_last_display.insert(tk.END, f"{key} : {first_vt}\n")

        self.first_last_display.insert(tk.END, "\nLastVT:\n")
        for key, value in last_vt_dict.items():
            last_vt = '  '.join(value)
            self.first_last_display.insert(tk.END, f"{key} : {last_vt}\n")

        self.first_last_display.config(state=tk.DISABLED)

    # 展示算符优先矩阵
    def show_matrix(self):

        get_matrix()
        self.matrix_display.config(state=tk.NORMAL)
        self.matrix_display.delete(1.0, tk.END)
        for row in mtr:
            self.matrix_display.insert(tk.END, '\t'.join([c if c != 'n' else '' for c in row]) + '\n')
        self.matrix_display.config(state=tk.DISABLED)

    # 转换表达式并显示三元式
    def convert_expression(self):
        """
        将输入的算术表达式转换为三元式并显示
        """
        expression = self.expression_entry.get()
        if expression:
            result = start(expression + '#')
            self.result_display.config(state=tk.NORMAL)
            self.result_display.delete(1.0, tk.END)
            for line in result:
                self.result_display.insert(tk.END, line + '\n')
            self.result_display.config(state=tk.DISABLED)
        else:
            messagebox.showwarning("输入错误", "请输入算术表达式")

                                                                                                                                                  # 判断一个文法是否左递归
        def __judgeLeftRecursion(self):
            # 包括直接左递归和间接左递归
            # 先判断直接左递归
            isRecursion = self.__subRecursion(self.grammar)
            if isRecursion:
                print('该文法是直接左递归')
            # 再判断间接左递归，修改文法，从后往前，依次将后面的非终结符的推导替换到前面相应位置
            if isRecursion is False:  # 不是直接左递归，判断是否是间接
                tmpLL1Grammar = self.modify()  # 是的话就执行替换
                isRecursion = self.__subRecursion(tmpLL1Grammar)  # 再判断修改后的文法是否含直接左递归
                if isRecursion:
                    print('该文法是间接左递归')
                    self.grammar = tmpLL1Grammar
            return isRecursion

        # 修改文法，将后面的非终结符的推导放到前面出现的位置上，可能得到直接左递归
        def modify(self):
            tmpLL1Grammar = self.grammar.copy()
            tmp2 = self.grammar.copy()
            # 从后往前，依次把后面的所有候选替换到前面出现的位置处
            keys = list(tmpLL1Grammar.keys())  # 把键转换为列表类型
            keys.reverse()  # 将键倒序，方便后面代码编写
            keylen = len(keys)
            for i in range(1, keylen):
                tmpDe = tmpLL1Grammar[keys[i]].copy()
                toBeMoved = []
                for de in tmp2[keys[i]]:
                    # 如果是空字或者首字是终结符，则这个key推出的产生式就没有左递归
                    if de == '' or de[0] in self.Terminater:
                        continue
                    else:
                        deLen = len(de)
                        for j in range(deLen):
                            if de[j] in self.Terminater:
                                continue
                            elif de[j] in self.NonTerminater and i > keys.index(de[j]):
                                # print('碰到非终结符，把', de[j], '的推导加入')
                                for x in tmpLL1Grammar[de[j]]:
                                    t = x + de[j + 1:]
                                    if t not in tmpDe:
                                        tmpDe.append(t)
                                toBeMoved.append(de)  # 这个含非终结符的推导要删掉，所以先暂时存放着

                for moved in toBeMoved:
                    if moved in tmpDe:
                        tmpDe.remove(moved)

                tmpLL1Grammar[keys[i]] = tmpDe
            return tmpLL1Grammar

        # 判断左递归的子程序，判断是否是直接左递归
        def __subRecursion(self, grammar):
            isRecursion = False
            for key in grammar.keys():
                for derivation in grammar[key]:
                    if derivation == '':  # 推出空字，就继续判断后面的推导
                        continue
                    elif derivation[0] == key:
                        isRecursion = True
                        break
                if isRecursion is True:
                    break

            return isRecursion

        # 判断一个文法是否是LL（1）文法
        def judgeLL1(self):
            # 初始化文法时已经判断了是否左递归，
            # 因此只用判断剩下两个规则，对每个非终结符，调用firstA，求它的每个产生式的first集
            # 调用修改文法，再进行判断
            tmpLL1Grammar = self.grammar.copy()
            isLL1 = True
            for key in tmpLL1Grammar.keys():
                isLL1 = True
                derivation = tmpLL1Grammar[key]
                alpha = []
                for de in derivation:
                    if de == '':
                        alpha.append('')
                    else:
                        alpha.append(de[0])
                alphaLen = len(alpha)
                for i in range(alphaLen - 1):
                    for j in range(i + 1, alphaLen):
                        if self.First[alpha[i]] == self.First[alpha[j]]:
                            isLL1 = False
                        break
                    if not isLL1:
                        break

            if not isLL1:
                messagebox.showinfo('错误！', '该文法不是LL（1）文法，无法执行分析！')
                return
            # 再看每个文法的所有候选首符集，
            for key in self.grammar.keys():
                derivation = self.grammar[key]
                if '' in derivation:  # 如果有空字
                    if self.__intersection(key):  # 如果非终结符key的first集和follow集的交集不为空
                        isLL1 = False
                        break

            if isLL1 is False:
                messagebox.showinfo('错误！', '该文法不是LL（1）文法，无法执行分析！')
            else:
                print('该文法是LL(1)文法')

        # 求非终结符A的first集和follow集的交集
        def __intersection(self, A):
            res = [x for x in self.First[A] if x in self.Follow[A]]
            return res
                                                                                                                                         # 消除直接左递归的算法
        def modifyLeftRecusion(self):
            # 先创建一个候选字母表
            toBeChoosed = [chr(ord('A') + x) for x in range(26)]
            toBeChoosed = [x for x in toBeChoosed if x not in self.grammar.keys()]  # 去掉已经有的字母
            tmpLL1Grammar = self.grammar.copy()
            for key in tmpLL1Grammar.keys():
                derivation = tmpLL1Grammar[key]
                tmpDe = tmpLL1Grammar[key].copy()
                isModify = False
                toBeMoved = []
                stay = []
                newNT = ''
                for de in derivation:
                    if de == '':
                        continue
                    if de[0] == key:  # 找到直接左递归的推导
                        toBeMoved.append(de)
                        stay.append(de[1:])
                        #newNT = random.choice(toBeChoosed)
                        isModify = True
                if isModify:  # 根据标志判断是否进行修改
                    for move in toBeMoved:  # 把非终结符开头的推导删掉
                        tmpDe.remove(move)
                    for i in range(len(tmpDe)):  # 其余推导在末尾加上新的非终结符号
                        tmpDe[i] += newNT
                    self.NonTerminater.append(newNT)
                    newDe = [s + newNT for s in stay]  # 原来那个要被替换掉的产生式的非终结符
                    newDe.append('')  # 加入空字
                    self.grammar[key] = tmpDe
                    self.grammar[newNT] = newDe
            # 修改完后，把不会出现的推导去掉
            occurTimes = {}  # 创建一个空字典，存放每个非终结符的出现次数
            for value in self.grammar.values():
                for t in value:
                    for subT in t:
                        if subT == '':
                            continue
                        elif subT in self.NonTerminater:
                            occurTimes[subT] = occurTimes.get(subT, 0) + 1
            popKeys = [key for key in self.grammar.keys() if key not in occurTimes.keys()]
            for k in popKeys:
                self.grammar.pop(k)
                self.NonTerminater.remove(k)

            self.__calTerAndNonTer()  # 更新终结符和非终结符,first集和follow集
            self.__first()
            self.__follow()

        # 求预测分析表
        def genAnalysisTable(self):
            # 用一个二维字典来表示分析表，这样索引的时候好查
            self.PredictTable = {}
            # 先定义一个分析表终结符
            self.tableTerminater = self.Terminater.copy()
            for first in self.First.values():
                for f in first:
                    if f not in self.tableTerminater:
                        self.tableTerminater.append(f)

            for follow in self.Follow.values():
                for f in follow:
                    if f not in self.tableTerminater:
                        self.tableTerminater.append(f)
            if '' in self.tableTerminater:  # 把空字去掉，因为空字不能出现在follow集中
                self.tableTerminater.remove('')

            print('预测分析表如下:')
            # 遍历所有非终结符号
            for nT in self.NonTerminater:
                self.PredictTable[nT] = {}  # 初始化每个非终结符的预测分析表条目

                # 遍历所有终结符号
                for T in self.tableTerminater:
                    derivation = self.grammar[nT]  # 获取非终结符的所有产生式

                    # 检查是否能直接推导
                    if T in derivation:  # 如果终结符T在产生式中
                        self.PredictTable[nT][T] = nT + '->' + T  # 直接将产生式添加到预测分析表中

                    # 否则检查是否在FIRST集中
                    elif T in self.First[nT]:  # 如果终结符T在非终结符nT的FIRST集中
                        find = False  # 初始化查找标志

                        # 遍历所有产生式
                        for de in derivation:
                            if T in de:  # 如果产生式de包含终结符T
                                self.PredictTable[nT][T] = nT + '->' + de  # 将产生式添加到预测分析表中
                                find = True  # 标记为已找到
                                break  # 跳出循环

                        # 如果在之前的循环中没有找到合适的产生式
                        if not find:
                            for de in derivation:
                                for subDe in de:  # 遍历产生式中的每个符号
                                    if T in self.First[subDe]:  # 如果T在子产生式的FIRST集中
                                        self.PredictTable[nT][T] = nT + '->' + de  # 将产生式添加到预测分析表中
                                        find = True  # 标记为已找到
                                        break  # 跳出内层循环
                                if find:
                                    break  # 跳出外层循环

                    # 如果终结符在FOLLOW集中，再看空串是否是其中一个推导式
                    elif T in self.Follow[nT]:  # 如果终结符T在非终结符nT的FOLLOW集中
                        if '' in derivation:  # 如果产生式包含空串
                            for fo in self.Follow[nT]:  # 遍历FOLLOW集中的每个符号
                                self.PredictTable[nT][fo] = nT + '->ε'  # 将空串产生式添加到预测分析表中
                        else:
                            self.PredictTable[nT][T] = ''  # 如果没有空串产生式，标记为空

                    # 如果不在FIRST集和FOLLOW集中
                    else:
                        self.PredictTable[nT][T] = ''  # 标记为空
    # 保存结果到文件
    def save_results(self):
        """
        保存文法规则、FirstVT和LastVT集合、算符优先矩阵和三元式结果到文件
        """
        filename = filedialog.asksaveasfilename(defaultextension=".txt",
                                                filetypes=[("Text files", "*.txt")],
                                                title="保存结果到文件")
        if filename:
            try:
                with open(filename, 'w') as file:
                    # 保存文法规则
                    file.write("文法规则:\n")
                    for info in lang:
                        for right in info.right:
                            file.write(f"{info.left} --> {right}\n")

                    # 保存FirstVT和LastVT集合
                    file.write("\nFirstVT:\n")
                    first_vt_dict = {}
                    last_vt_dict = {}

                    for info in lang:
                        if info.left not in first_vt_dict:
                            first_vt_dict[info.left] = info.first
                        else:
                            first_vt_dict[info.left] |= info.first

                        if info.left not in last_vt_dict:
                            last_vt_dict[info.left] = info.last
                        else:
                            last_vt_dict[info.left] |= info.last

                    for key, value in first_vt_dict.items():
                        first_vt = '  '.join(value)
                        file.write(f"{key} : {first_vt}\n")

                    file.write("\nLastVT:\n")
                    for key, value in last_vt_dict.items():
                        last_vt = '  '.join(value)
                        file.write(f"{key} : {last_vt}\n")

                    # 保存算符优先矩阵
                    file.write("\n算符优先矩阵:\n")
                    for row in mtr:
                        file.write('\t'.join([c if c != 'n' else '' for c in row]) + '\n')

                    # 保存三元式
                    file.write("\n三元式:\n")
                    expression = self.expression_entry.get()
                    if expression:
                        result = start(expression + '#')
                        for line in result:
                            file.write(line + '\n')
                    else:
                        file.write("无三元式输出\n")
                messagebox.showinfo("保存成功", "结果已成功保存到文件")
            except Exception as e:
                messagebox.showerror("保存失败", f"保存文件时发生错误: {e}")

# 程序入口，创建主窗口并运行应用
if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("680x800")  # 设置主窗口初始大小
    app = ExpressionConverterApp(root)
    root.mainloop()
