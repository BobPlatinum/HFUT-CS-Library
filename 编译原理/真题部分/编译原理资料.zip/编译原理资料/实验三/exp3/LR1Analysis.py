
from tkinter.filedialog import askopenfilename
import tkinter.messagebox as messagebox
from tkinter.messagebox import showinfo
from tkinter import *

class Stack:

	def __init__(self):
		self.__length = 0  # 记录栈内元素数量
		self.__data = []  # 用一个列表来表示栈

	# 进栈
	def push(self, x):
		if x == '':
			messagebox.showinfo("Error", "进栈元素不能为空!")
		else:
			self.__data.append(x)
			self.__length += 1

	# 弹栈
	def pop(self):
		self.__length = len(self.__data)
		if self.__length == 0:
			messagebox.showinfo("Error", "栈已空，不能pop!")
		else:
			self.__length -= 1
			res = self.__data.pop(self.__length)
			return res

	# 栈的所有内容以字符串形式返回
	def toString(self):
		res = ''
		for value in self.__data:
			if isinstance(value, int) and value >= 10:  # 检查 value 是否为整数且大于等于 10
				res += f' {value} '
			else:
				res += str(value)  # 直接添加 value，无论是否为数字
		return res.strip()  # 去掉结果字符串开头和结尾的多余空格

	# 查看栈顶元素
	def top(self):
		self.__length = len(self.__data)
		if self.__length == 0:
			messagebox.showinfo("警告", "栈已空!")
		else:
			return self.__data[self.__length - 1]



# 文法类
class LR1Grammar:

	def __init__(self, filename):
		self.grammar = [] # 用列表放文法，每个推导以一个元组表示
		self.grammar2 = {}
		self.Terminater = []
		self.NonTerminater = []
		self.Terminater = []
		self.First = {}
		self.projectSetFamily = [] # 项目集族，用列表存，一个项目集是一个列表
		self.actionTable = {} # action表
		self.GOTOtable = {} # goto表
		# 一个元组，（T， n， p） T表示一个产生式编号，n表示右边圆点的位置，p表示展望符，是一个列表
		try:
			f = open(filename, 'r')
			for line in f:
				nT = line[0] # 一个推导的非终结符
				derivation = line[3:].replace('\n', '')  # 右边的产生式
				self.grammar.append((nT, derivation.replace('蔚', 'ε')))
			f.close()
			print('第一种文法表示法：', self.grammar)
		except: # 打开文件失败就抛出异常，待GUI处理
			raise IOError('文件打开失败!')

		self.__CalnTandT()  # 求终结符和非终结符
		for nT in self.NonTerminater:
			self.grammar2[nT] = []
		for item in self.grammar:
			self.grammar2[item[0]].append(item[1])
		print('第二种文法表示法:')
		for key in self.grammar2.keys():
			print(key, '->', self.grammar2[key])
		print('非终结符集合：', self.NonTerminater)
		print('终结符集合:', self.Terminater)
		self.allFirst()
		self.calProjectSetFamily()
		self.calActionAndGOTOTable()

	# 计算终结符和非终结符
	def __CalnTandT(self):
		for item in self.grammar:
			if item[0] not in self.NonTerminater:
				self.NonTerminater.append(item[0])
		for item in self.grammar:
			for subDe in item[1]:
				if subDe not in self.NonTerminater \
						and subDe not in self.Terminater:
					self.Terminater.append(subDe)

	# 求first集
	def allFirst(self):
		for T in self.Terminater: # 终结符的first集就是他自己
			self.First[T] = [T]
		for nT in self.NonTerminater:# 先循环给非终结符的first集一个空列表
			self.First[nT] = []
		if 'ε' in self.First.keys(): # 空字不是终结符，得去掉
			self.First.pop('ε')
		for nT in self.NonTerminater:
			derivation = self.grammar2[nT]
			if 'ε' in derivation:   # 空字在推导中，就把空字也加入它的first集中
				self.First[nT].append('ε')
		for item in self.grammar:
			derivation = item[1]
			if derivation == 'ε':
				continue
			if derivation[0] in self.Terminater:
				self.First[item[0]].append(derivation[0])
		# 再倒着来，从最后一个文法开始往前推
		for i in range(len(self.grammar) - 1, -1, -1):
			if self.grammar[i][1] == 'ε':
				continue
			de = self.grammar[i][1]
			allHaveNone = True
			for subDe in de:
				if subDe in self.NonTerminater: # 如果一个产生式右边第一个字符是非终结符
					for f in self.First[subDe]:# 就把这个非终结符的first集给推出它的非终结符
						if f not in self.First[self.grammar[i][0]]:
							self.First[self.grammar[i][0]].append(f)
					if 'ε' not in self.First[subDe]:
						allHaveNone = False
						break
				elif subDe in self.Terminater: # 产生式中有一个终结符，就退出for
					break
			# for正常执行完，说明一个产生式右边全是非终结符
			else:
				if allHaveNone: # 再看这个全部是非终结符的标记是否为真
					self.First[self.grammar[i][0]].append('ε')


	# 求一个符号串X的first集
	def first(self, X):
		if self.First == {}:
			print('请先调用allFirst方法求出所有first集!')
			return
		# 符号串，所以默认没有空字，就不用考虑空字
		res = []
		for subX in X:
			if subX in self.NonTerminater: #如果字符是非终结符
				res += self.First[subX]
				if 'ε' not in self.First[subX]: # 如果这个非终结符的first集没有空字，就退出
					break   # 有空字，就能继续往后看
			elif subX in self.Terminater and subX not in res: # 终结符就加入结果列表并退出循环
				res.append(subX)
				break
		return res



	# 求文法的项目集族
	def calProjectSetFamily(self):
		# 元组（T，n，p）
		T = 0 # 第一个产生式标号为0
		n = 1 # 第一个项目右边圆点位置是第一个
		p = '#' # 第一个项目的展望符肯定是#
		I0 = self.__closure([(T, n, p)])  # 先求第一个项目的闭包
		self.projectSetFamily.append(I0) # 加入项目集族
		allChar = self.NonTerminater + self.Terminater # 文法的所有符号
		allChar.remove(self.NonTerminater[0]) #去掉拓广文法的最开始符
		for projectset in self.projectSetFamily: # 对每个项目集和每个文法，求
			for char in allChar:
				J = self.__J(projectset, char)
				if not J:
					continue
				tmp = self.__closure(J)
				if tmp not in self.projectSetFamily:
					self.projectSetFamily.append(tmp)
		# 输出所有项目集
		for i in range(len(self.projectSetFamily)):
			print('项目集', i, ':')
			for item in self.projectSetFamily[i]:
				print(item)


	# 求一个项目的闭包
	def __closure(self, project):
		# project是一个项目，是一个三个元素的元组
		res = project
		for item in project:
			T = item[0] # 产生式编号
			n = item[1] # 右边圆点位置，用来索引圆点右边那个符号
			p = item[2] # 当前项目item的展望符
			sizeOfProduct = len(self.grammar[T][1])
			if n == sizeOfProduct + 1:  # 如果圆点的位置在产生式的最后，那么就跳过当前这个产生式，看下一个
				continue
			X = self.grammar[T][1][n - 1] # 索引圆点右边那个符号
			if X in self.NonTerminater: # 如果X是非终结符
				# 先求这个X后面的符号连接上展望符的first集
				if n == sizeOfProduct:
					first = p
				else:
					# 再求展望符
					first = self.first(self.grammar[T][1][n] + p)

				prods = []    # 求X作为产生式左边的推导的编号
				for i in range(len(self.grammar)):
					if self.grammar[i][0] == X:
						prods.append(i)
				# 把不在原项目集中的项目加到当前项目集中
				for prod in prods:
					for f in first:
						if (prod, 1, f) not in res:
							res.append((prod, 1, f))
			# else就是终结符，就不管

		return res


	# 求一个项目集J
	def __J(self, I, X):
		res = []
		for project in I:
			T = project[0] # 项目的产生式的标号
			n = project[1] # 右边圆点位置
			p = project[2] # 项目的展望符
			product = self.grammar[T][1] # 产生式右边的字符串
			# 遍历这个推导，由于字符串的特性，因此这里用下标的方式来遍历
			for i in range(len(product)):
				if product[i] == X: # 第i个字符是X，
					if i == n - 1: # 如果它在圆点右边，就把它加入res
						res.append((T, n + 1, p))
		return res


	# 定义Go函数,返回一个项目集在项目集族中的标号
	def __GO(self, I, X):
		J = self.__J(self.projectSetFamily[I], X)
		closureJ = self.__closure(J)
		res = -1
		for i in range(len(self.projectSetFamily)):
			if closureJ == self.projectSetFamily[i]:
				res = i
				break

		return res


	# 求action表	和goto表,
	def calActionAndGOTOTable(self):
		statusNum = len(self.projectSetFamily) # 状态数
		Terminater = self.Terminater.copy()
		Terminater.append('#')

		# 先把所有项目集放到一个列表里
		allProject = []
		for projectSet in self.projectSetFamily:
			allProject += [x for x in projectSet if x not in allProject]
		for k in range(statusNum):   # 遍历每个项目集
			self.actionTable[k] = {}# 初始，给每个状态一个空字典，这样就能通过双重字典来实现两个字符索引
			self.GOTOtable[k] = {}
			for T in self.Terminater:
				self.actionTable[k][T] = '' # 先给表中每个元素赋值空字
			self.actionTable[k]['#'] = ''   # 把’#‘也给加上
			for NT in self.NonTerminater:
				self.GOTOtable[k][NT] = ''

		for project in allProject: # 遍历每个项目
			T = project[0]  # 项目的产生式的标号
			n = project[1]  # 右边圆点位置
			p = project[2]  # 项目的展望符
			sizeOfProduct = len(self.grammar[T][1])
			for k in range(statusNum):
				if project not in self.projectSetFamily[k]: # 某项目不在某项目集，continue
					continue
				# 执行到这说明该项目在某项目集中
				if (0, 2, '#') == project:  # 先判断第三个规则，符合的话直接退出当前循环
					self.actionTable[k]['#'] = 'acc'
				else:
					if n == sizeOfProduct + 1:  # 第二个规则，因为如果先判断第一个的话要用到n-1，而n-1可能会越界，所以先判第二
						self.actionTable[k][p] = 'r' + str(T)
					else:
						a = self.grammar[T][1][n - 1]  # 索引圆点右边那个符号,判断第一个规则
						if a in Terminater:
							j = self.__GO(k, a)
							self.actionTable[k][a] = 's' + str(j) if j != -1 else ''
						A = self.grammar[T][0]  # 第四个规则
						j = self.__GO(k, A)
						self.GOTOtable[k][A] = j if j != -1 else ''


class LR1GUI:

	# 初始化，包括窗体，按钮等,要用到文法，所以给一个文法参数
	def __init__(self):
		self.window = Tk()  # 创建一个窗口

		self.window.title('LR(1)分析 -- 许航睿')  # 标题
		self.window.geometry('800x600')  # 设置窗口大小
		self.window.configure(bg='#ffffff')  # 设置窗口背景颜色

		self.LR1Grammar = None  # 文法对象先初始化为None，待打开文件后再初始化
		self.program = ""  # 待分析的程序段
		self.grammarLabels = []  # 记录展示的文法和对应的first和follow的标签
		self.R1analysisTableLabels = []  # 记录预测分析表的标签
		self.analysisTableLabels = []  # 记录分析结果的表格标签

		# 设置滚动条和画布
		outer_frame = Frame(self.window)
		outer_frame.pack(fill=BOTH, expand=True)

		canvas = Canvas(outer_frame, bg='#ffffff')
		scrollbar = Scrollbar(outer_frame, orient="vertical", command=canvas.yview)
		canvas.configure(yscrollcommand=scrollbar.set)

		scrollbar.pack(side="right", fill="y")
		canvas.pack(side="left", fill="both", expand=True)

		inner_frame = Frame(canvas, bg='#ffffff')
		canvas.create_window((400, 0), window=inner_frame, anchor='center')
		inner_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
		inner_frame.bind_all("<MouseWheel>", lambda event: self._on_mousewheel(event, canvas))

		self.inner_frame = inner_frame  # 保存内部框架的引用

		# 设置布局
		frame = Frame(inner_frame, bg='#ffffff')  # 这个框架放介绍文字
		frame1 = Frame(inner_frame, bg='#ffffff')  # 这个框架放提示输入文法
		frame2 = Frame(inner_frame, bg='#ffffff')  # 这个框架放读取文法程序
		self.frame3 = Frame(inner_frame, bg='#ffffff')  # 这个框架放文法，first集，follow集
		self.frame6 = Frame(inner_frame, bg='#ffffff')  # 放预测分析表
		self.frame5 = Frame(inner_frame, bg='#ffffff')  # 新增行：放分析结果

		frame.pack(pady=10)
		frame1.pack()
		frame2.pack(pady=10)
		self.frame3.pack()
		self.frame6.pack(pady=10)
		self.frame5.pack()  # 确保结果框架也被包装和显示

		self.v2 = StringVar()  # 获取输入程序段的文本框
		self.btShowFirstFollow = Button(frame1, text='生成First集', command=self.__showGrammar,
										font=('KaiTi', 13), bg='#2196F3', fg='white', width=20)
		self.btShowPredictTable = Button(frame1, text='生成LR(1)分析表', command=self.showLR1analysisTable,
										 font=('KaiTi', 13), bg='#FF9800', fg='white', width=18)
		self.btShowFirstFollow.grid(row=1, column=3, padx=10)
		self.btShowPredictTable.grid(row=1, column=4, padx=10)

		# 添加标签，输入框，按钮等组件
		welcome = Label(frame, text='LR(1)文法分析器--by 许航睿', font=('KaiTi', 20, 'bold'), anchor='center', bg='#ffffff')
		btChoose = Button(frame1, text='打开', command=self.__getFileByInteract, font=('KaiTi', 13), bg='#4CAF50',
						  width=18, fg='white')
		promptLable = Label(frame2, text='请输入一个程序段:', font=('KaiTi', 14), bg='#ffffff')
		entryProgram = Entry(frame2, textvariable=self.v2, justify=LEFT, width=30, font=('KaiTi', 14))
		analysisButton = Button(frame2, text='执行分析', command=self.analysis, font=('KaiTi', 12), bg='#4CAF50',
								fg='white')

		welcome.grid()
		btChoose.grid(row=1, column=2)
		promptLable.grid(row=2, column=1)
		entryProgram.grid(row=2, column=2)
		analysisButton.grid(row=2, column=3)

		self.window.mainloop()  # 事件循环

	def _on_mousewheel(self, event, canvas):
		canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

	# 交互式选择文法文件
	def __getFileByInteract(self):
		fileName = askopenfilename()
		print(fileName)
		if fileName:
			self.LR1Grammar = LR1Grammar(fileName)  # 初始化文法对象
			messagebox.showinfo("提示", "文件已载入，可以生成First集和分析表。")

			# 清空之前的分析结果和标签
			for label in self.grammarLabels:
				label.destroy()
			self.grammarLabels = []  # 清空保存标签的列表

			for label in self.R1analysisTableLabels:
				label.destroy()
			self.R1analysisTableLabels = []  # 清空保存预测分析表标签的列表
			# 清空之后立即在原地刷新区域（示例）
			self.refreshGrammarArea()
			self.refreshPredictTableArea()
			self.refreshAnalysisArea()

	def refreshGrammarArea(self):
		for label in self.grammarLabels:
			label.destroy()
		self.grammarLabels = []
		# 可以在这里添加恢复到初始状态的文本或标签
		label = Label(self.frame3, text="等待生成First集...", font=('KaiTi', 12), bg='#ffffff')
		label.pack()
		self.grammarLabels.append(label)

	def refreshPredictTableArea(self):
		for label in self.R1analysisTableLabels:
			label.destroy()
		self.R1analysisTableLabels = []
		# 可以在这里添加恢复到初始状态的文本或标签
		label = Label(self.frame6, text="等待生成LR(1)分析表...", font=('KaiTi', 12), bg='#ffffff')
		label.pack()
		self.R1analysisTableLabels.append(label)

	def refreshAnalysisArea(self):
		# 先清空之前的标签
		for label in self.analysisTableLabels:
			label.destroy()
		self.analysisTableLabels = []

		# 添加恢复到初始状态的文本或标签
		label = Label(self.frame5, text="等待生成分析结果...", font=('KaiTi', 12), bg='#ffffff')
		label.pack()
		self.analysisTableLabels.append(label)

	# 在GUI上展示文法和文法的first集
	def __showGrammar(self):
		if not self.LR1Grammar:  # 检查是否已经加载了文法文件
			showinfo("错误", "请先选择一个文法文件！")
			return
		if self.grammarLabels:  # 每次展示前先把前面一个文法的所有标签删掉
			for label in self.grammarLabels:
				label.destroy()
		self.grammarLabels = []
		r = 1

		# 添加表头
		l = Label(self.frame3, text='所选文法如下：', font=('KaiTi', 14), justify=LEFT, bg='#ffffff', anchor='w')
		l.grid(row=r, column=1, padx=5, pady=5, sticky=W)
		self.grammarLabels.append(l)

		l = Label(self.frame3, text='FIRST集：', font=('KaiTi', 14), justify=LEFT, bg='#ffffff', anchor='w')
		l.grid(row=r, column=2, padx=5, pady=5, sticky=W)
		self.grammarLabels.append(l)
		r = 2

		for key in self.LR1Grammar.grammar2.keys():
			col = 1
			string = key + '->'  # 先展示文法
			tmp = self.LR1Grammar.grammar2[key]
			if '' in tmp:  # 展示的时候把空字''替换为'ε'
				tmp[tmp.index('')] = 'ε'
			string += '|'.join(tmp)
			l = Label(self.frame3, text=string, font=('KaiTi', 12), width=40, justify=LEFT, bg='#ffffff', anchor=W)
			l.grid(row=r, column=col, padx=5, pady=5, sticky=W)
			self.grammarLabels.append(l)

			col = 2
			string = 'FIRST(' + key + ')={'  # 再展示first
			tmp = self.LR1Grammar.First[key]
			if '' in tmp:
				tmp[tmp.index('')] = 'ε'
			string += ','.join(tmp) + '}'
			l = Label(self.frame3, text=string, font=('KaiTi', 12), width=25, justify=LEFT, bg='#ffffff', anchor=W)
			l.grid(row=r, column=col, padx=5, pady=5, sticky=W)
			self.grammarLabels.append(l)


			r += 1

	# 获取输入程序段
	def __getProgram(self):
		tmpStr = self.v2.get()
		if tmpStr == '':  # 如果没有输入，就提示错误
			messagebox.showinfo("错误", "请输入程序段！")
		else:  # 有输入,将该字符串返回
			return tmpStr

	# 展示LR1分析表
	def showLR1analysisTable(self):
		if not self.LR1Grammar:  # 检查是否已经加载了文法文件
			messagebox.showinfo("错误", "请先选择一个文法文件！")
			return
		if self.R1analysisTableLabels:  # 每次先把前面的文法的分析表删除掉
			for label in self.R1analysisTableLabels:
				label.destroy()
		self.R1analysisTableLabels = []

		# 表头
		r, col = 1, 1
		l = Label(self.frame6, text='LR（1）分析表', font=('KaiTi', 16, 'bold'), bg='#f0f0f0', borderwidth=2,
				  relief='solid')
		l.grid(row=r, column=col, columnspan=len(self.LR1Grammar.Terminater) + len(self.LR1Grammar.NonTerminater) + 2,
			   sticky='ew')
		self.R1analysisTableLabels.append(l)

		# 状态标签
		r += 1
		col = 1
		l = Label(self.frame6, text='状态', width=8, background='#d3d3d3', font=('Arial', 10, 'bold'), borderwidth=2,
				  relief='ridge')
		l.grid(row=r, column=col, rowspan=2, sticky='nsew')
		self.R1analysisTableLabels.append(l)
		col += 1

		# ACTION（动作）标签
		l = Label(self.frame6, text='ACTION（动作）', width=8 * len(self.LR1Grammar.Terminater), background='#d3d3d3',
				  font=('Arial', 10, 'bold'), borderwidth=2, relief='ridge')
		l.grid(row=r, column=col, columnspan=len(self.LR1Grammar.Terminater) + 1, sticky='nsew')
		self.R1analysisTableLabels.append(l)
		col += len(self.LR1Grammar.Terminater) + 1

		# GOTO（转换）标签
		l = Label(self.frame6, text='GOTO（转换）', width=8 * len(self.LR1Grammar.NonTerminater), background='#d3d3d3',
				  font=('Arial', 10, 'bold'), borderwidth=2, relief='ridge')
		l.grid(row=r, column=col, columnspan=len(self.LR1Grammar.NonTerminater), sticky='nsew')
		self.R1analysisTableLabels.append(l)

		# 终结符表头
		r += 1
		col = 2
		for T in self.LR1Grammar.Terminater:
			l = Label(self.frame6, text=T, width=8, background='#f0f0f0', borderwidth=2, relief='ridge',
					  font=('Arial', 10))
			l.grid(row=r, column=col, sticky='nsew')
			self.R1analysisTableLabels.append(l)
			col += 1

		# 加上结束符 #
		l = Label(self.frame6, text='#', width=8, background='#f0f0f0', borderwidth=2, relief='ridge',
				  font=('Arial', 10))
		l.grid(row=r, column=col, sticky='nsew')
		self.R1analysisTableLabels.append(l)
		col += 1

		# 非终结符表头
		for nT in self.LR1Grammar.NonTerminater:
			l = Label(self.frame6, text=nT, width=8, background='#f0f0f0', borderwidth=2, relief='ridge',
					  font=('Arial', 10))
			l.grid(row=r, column=col, sticky='nsew')
			self.R1analysisTableLabels.append(l)
			col += 1

		# 每个状态及其对应的分析结果
		r += 1
		for i in range(len(self.LR1Grammar.projectSetFamily)):
			col = 1
			l = Label(self.frame6, text=i, width=8, background='#e6e6e6', borderwidth=2, relief='ridge',
					  font=('Arial', 10))
			l.grid(row=r, column=col, sticky='nsew')
			self.R1analysisTableLabels.append(l)
			col += 1
			for T in self.LR1Grammar.Terminater:
				action_text = self.LR1Grammar.actionTable[i].get(T, '')
				l = Label(self.frame6, text=action_text, width=8, background='#ffffff', borderwidth=2, relief='ridge',
						  font=('Arial', 10))
				l.grid(row=r, column=col, sticky='nsew')
				self.R1analysisTableLabels.append(l)
				col += 1
			l = Label(self.frame6, text=self.LR1Grammar.actionTable[i].get('#', ''), width=8, background='#ffffff',
					  borderwidth=2, relief='ridge', font=('Arial', 10))
			l.grid(row=r, column=col, sticky='nsew')
			self.R1analysisTableLabels.append(l)
			col += 1
			for nT in self.LR1Grammar.NonTerminater:
				goto_text = self.LR1Grammar.GOTOtable[i].get(nT, '')
				l = Label(self.frame6, text=goto_text, width=8, background='#ffffff', borderwidth=2, relief='ridge',
						  font=('Arial', 10))
				l.grid(row=r, column=col, sticky='nsew')
				self.R1analysisTableLabels.append(l)
				col += 1
			r += 1

	# 执行分析,有错提示错误信息
	def analysis(self):
		if self.LR1Grammar is None:
			messagebox.showinfo("错误!", "未读取文法！请先选择一个文法！")
			return
		if self.analysisTableLabels:  # 每次先把前面的文法的分析表删除掉
			for label in self.analysisTableLabels:
				label.destroy()

		self.analysisTableLabels = []
		r = 1
		step_col_width = 6  # 步骤列宽度
		state_col_width = 15  # 状态和符号列宽度
		input_col_width = 12  # 输入串列宽度
		action_col_width = 42  # 动作列宽度

		# 创建标题
		title = Label(self.frame5, text="程序段分析结果", font=('KaiTi', 14), bg='#ffffff')
		title.grid(row=r, column=1, columnspan=5, sticky='nsew')
		self.analysisTableLabels.append(title)

		r += 1

		# 创建表头
		headers = ["步骤", "状态栈", "符号栈", "输入串", "动作"]
		col_widths = [step_col_width, state_col_width, state_col_width, input_col_width, action_col_width]
		for i, (header, width) in enumerate(zip(headers, col_widths)):
			label = Label(self.frame5, text=header, font=('KaiTi', 12), bg='#f0f0ff', width=width, relief='ridge')
			label.grid(row=r, column=i + 1, sticky='nsew')
			self.analysisTableLabels.append(label)

		r += 1
		step = 0  # 分析步数
		statusStack = Stack()  # 状态栈
		charStack = Stack()  # 符号栈
		index = 0  # 输入程序段的下标
		statusStack.push(0)  # 一开始先把0状态入栈
		charStack.push('#')  # '#'入栈
		self.program = self.__getProgram()  # 获取待分析程序段
		while self.program == '':
			self.program = self.__getProgram()
		if self.program[-1] != '#':  # 如果输入最后不是#，就给它加上个#, 防止用户忘记
			self.program += '#'

		actionTable = self.LR1Grammar.actionTable
		GOTOtable = self.LR1Grammar.GOTOtable
		success = True

		while True:
			a = self.program[index]
			i = statusStack.top()
			action = actionTable[i][a]
			charStContent = charStack.toString()
			statusStContent = statusStack.toString()
			remain = self.program[index:]
			print(f'第{step}步，a = {a}, i = {i}', end='')
			print(f'action = {action}')

			if action == 'acc':  # 接受
				print(f'接受，index = {index}')
				step_data = [str(step), statusStContent, charStContent, remain, '接受，分析成功']
				for j, (data, width) in enumerate(zip(step_data, col_widths)):
					label = Label(self.frame5, text=data, font=('KaiTi', 12), bg='#f0f0ff', width=width,
								  relief='ridge', anchor='w')
					label.grid(row=r, column=j + 1, sticky='nsew')
					self.analysisTableLabels.append(label)
				break
			elif action[0] == 's':  # 移进
				j = int(action[1:])  # 要移进的状态
				mess = f'action({i}, {a}) = {action}, 状态 {j} 入栈'
				step_data = [str(step), statusStContent, charStContent, remain, mess]
				for k, (data, width) in enumerate(zip(step_data, col_widths)):
					label = Label(self.frame5, text=data, font=('KaiTi', 12), bg='#f0f0ff', width=width,
								  relief='ridge', anchor='w')
					label.grid(row=r, column=k + 1, sticky='nsew')
					self.analysisTableLabels.append(label)
				statusStack.push(j)
				charStack.push(a)
				index += 1  # 输入串指针后移
				step += 1
			elif action[0] == 'r':  # 规约
				# 先从状态栈弹出n个状态，n为规约产生式的长度
				prodNum = int(action[1:])
				prod = self.LR1Grammar.grammar[prodNum][1]
				prodLen = len(prod)
				for _ in range(prodLen):  # 把n个字符从状态栈和符号栈弹出
					statusStack.pop()
					charStack.pop()
				# 将用到的规约式的非终结符入栈
				A = self.LR1Grammar.grammar[prodNum][0]
				charStack.push(A)
				i = statusStack.top()
				go = GOTOtable[i][A]
				statusStack.push(go)  # 新状态入栈
				mess = f'{action}: {self.LR1Grammar.grammar[prodNum][0]} -> {prod}, 规约, GOTO({i}, {A}) = {go}'
				step_data = [str(step), statusStContent, charStContent, remain, mess]
				for k, (data, width) in enumerate(zip(step_data, col_widths)):
					label = Label(self.frame5, text=data, font=('KaiTi', 12), bg='#f0f0ff', width=width,
								  relief='ridge', anchor='w')
					label.grid(row=r, column=k + 1, sticky='nsew')
					self.analysisTableLabels.append(label)
				step += 1
			else:
				messagebox.showinfo('错误！', '输入程序段非法！')
				success = False
				break
			r += 1

		if success:
			messagebox.showinfo('提示', '分析成功!')
		else:
			messagebox.showinfo('错误', '分析失败！')

	def exitPro(self):
		exit(0)


if __name__ == "__main__":
	LR1GUI()