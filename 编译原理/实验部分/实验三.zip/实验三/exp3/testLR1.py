
from LR1Analysis import LR1GUI
from LR1Analysis import LR1Grammar

LR1gui = LR1GUI()
