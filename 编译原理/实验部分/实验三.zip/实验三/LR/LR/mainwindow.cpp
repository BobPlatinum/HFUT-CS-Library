#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QApplication>
#include <QWidget>
#include <QLabel>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QStringList>
#include <QDebug>
#include <QPushButton>
#include <bits/stdc++.h>

using namespace std;

// 定义字符串对和数-字符串对
typedef pair<string, string> PSS;
typedef pair<int, string> PIS;
// 定义结构体 来存储 类似 S->a, # 类字符串
struct ind
{
    string s;
    string f;
    bool operator < (const ind &t) const
    {
        if (t.s == s) return t.f < f;

        return t.s < s;
    }
};
// 表示文法的个数
int n = 0;
// 表示项目的个数
int index = 0;
// 终结符
map<string, int> VT;
int cnt_vt = 0;
// 非终结符
map<string, int> VN;
int cnt_vn = 0;
// FIRST 和  FOLLOW 集合
set<string> FIRST[100];
set<string> FOLLOW[20];
// 项目集合
map<ind, int> I[100];
int cnt_i[100];
map<ind, int> Ip[100];
int cnt_ip[100];
// GO
map<PIS, int> GO;
// 分析表
map<PSS, string> mp;
// ACTION GOTO
map<PIS, string> ACTION;
map<PIS,int> GOTO;
// 先设置文法
string s[] = {"S->E", "E->E+T", "E->T", "T->T*F", "T->F", "F->(E)", "F->i"};
//string s[] = {"E->S", "S->BB", "B->aB", "B->b"};
// hash的终结符的数值
int get_VT (string c)
{
    if (!VT.count (c)) VT[c] = cnt_vt ++;

    return VT[c];
}
// hash的非终结符的数值
int get_VN (string c)
{
    if (!VN.count (c)) VN[c] = cnt_vn ++;

    return VN[c];
}
// 判断是否为非终结符
bool isVT (string c)
{
    char cd = c[0];
    if (cd >= 'A' and cd <= 'Z') return false;

    return true;
}
// hash对应的VN
string num_to_VN (int c)
{
    for (auto [x, v] : VN)
        if (v == c)
            return x;
}
// hash对应的VT
string num_to_VT (int c)
{
    for (auto [x, v] : VT)
        if (v == c)
            return x;
}
// 得到一段字符串的FIRST集合
set<string> get_FIRST_of (string af)
{
    set<string> first;
    string sta = "";
    sta += af[0];

    // 从前往后扫描, 如果出现第一个FIRST集中不含"$"则退出求解
    for (int i = 0; i < af.size(); i ++)
    {
        bool has_e = false;

        if (VT.count (sta))
        {
            if (sta != "$")
                first.insert (sta);
            else if (sta == "$") has_e = true;
        }
        else
        {
            for (auto x : FIRST[get_VN (sta)])
            {
                if (x != "$")
                    first.insert (x);
                else if (x == "$") has_e = true;
            }
        }

        // 如果当前has_e还是true 将当前字符转换为下一字符继续求解FIRST集
        if (i + 1 < af.size() and has_e) sta = af[i + 1];

        if (i == af.size() - 1 and has_e) first.insert ("$");
    }

    return first;
}
// FIRST集合的求解
void get_FIRST()
{
    // 定义布尔变量 表示当前循环时是否增加了集合中符号的数量
    bool has_add = true;

    while (has_add)
    {
        // 优先置为false 当往集合中加入新的符号置为true
        has_add = false;

        for (int i = 0 ; i < n ; i ++)
        {
            // 求出 ‘->’ 后的字符串
            int first_pos = 0;
            string now_vn = "";

            for (int j = 0; j < s[i].size(); j ++)
            {
                if (j == 0) now_vn += s[i][j];

                if (j + 1 < s[i].size() and s[i][j] == '-' and s[i][j + 1] == '>')
                    first_pos = j + 2;
            }

            // 开始对后续的字符串分类讨论求解FIRST
            for (int j = first_pos; j < s[i].size(); j ++)
            {
                string a = "";
                a += s[i][j];

                // 如果是终结符直接加上
                if (VT.count (a) and !FIRST[get_VN (now_vn)].count (a))
                {
                    FIRST[get_VN (now_vn)].insert (a);
                    has_add = true;
                    break;
                }
                else if (!VT.count (a)) //  如果是非终结符，将其的FIRST集 / {$} 加入集合
                {
                    // 定义走到当前符号的FIRST集是否包含"." , 如果是的话接下来一个非终结符的FIRST集也可以继续加入集合
                    // 优先置为false 判断到存在"."就置为true
                    bool has_e = false;

                    for (auto p : FIRST[get_VN (a)])
                    {
                        if (p != "$" and !FIRST[get_VN (now_vn)].count (p))
                        {
                            FIRST[get_VN (now_vn)].insert (p);
                            has_add = true;
                        }
                        else if (p == "$") has_e = true;
                    }

                    if (!has_e) break;

                    if (j == s[i].size() - 1 and has_e and !FIRST[get_VN (now_vn)].count ("."))
                    {
                        FIRST[get_VN (now_vn)].insert ("$");
                        has_add = true;
                    }
                }
                else break;
            }
        }
    }

    // 打印输出FIRST集合
//	cout << "FIRST :" << endl;
//	for(int i = 0; i < cnt_vn; i ++)
//	{
//		cout << num_to_VN(i) << ' ' << ' ';
//		for(auto x : FIRST[i])
//			cout << x << ' ';
//		cout << endl;
//	}
}
// 返回一个字符串的.的位置
int get_point (string s)
{
    int point_pos = 0;

    for (int i = 0; i < s.size(); i ++)
        if (s[i] == '.')
            point_pos = i;

    return point_pos;
}
// 得到ACTION 和 GOTO表信息
void get_tab()
{
    for (int i = 0; i < index ; i ++)
    {

        for (auto x : I[i])
        {
            // 如果是S'->S., #  ACTION上加上"acc"
            if (x.first.s == s[0] + "." and x.first.f == "#")
            {
                ACTION[ {i, "#"}] = "acc";
            }
            else
            {
                // 是其他到句末的项目， ACTION加上r动作
                int which = -1;

                for (int c = 0 ; c < n ; c ++)
                    if (s[c] + "." == x.first.s)
                        which = c;

                string res = "r";
                res += to_string(which);
                if(which != -1) ACTION[ {i, x.first.f}] = res;
            }
        }

        // 如果是终结符 ACTION加上s动作
        for (int j = 0 ; j < cnt_vt; j ++)
        {
            auto c = num_to_VT (j);
            int p = GO[ {i, c}];

            string res = "s";
            res += to_string(p);
            if (p != -1) ACTION[ {i, c}] = res;
        }

        // 如果是非终结符 GOTO加上对应状态数字
        for (int j = 0; j < cnt_vn; j ++)
        {
            auto c = num_to_VN (j);
            int p = GO[ {i, c}];
            if(p >= 0 and p < index) GOTO[ {i, c}] = p;
        }

    }

    // 给其他没有抵达的状态置为-1和"error"
    for (int i = 0 ; i < cnt_vn; i ++)
        for (int j = 0; j < index ; j ++)
            if (!GOTO.count ({j, num_to_VN (i) }))
                GOTO[ {j, num_to_VN (i) }] = -1;

    for (int i = 0 ; i < cnt_vt; i ++)
        for (int j = 0 ; j < index ; j ++)
            if (!ACTION.count ({j, num_to_VT (i) }))
                ACTION[ {j, num_to_VT (i) }] = "error";
}
// 给产生式加上"."
string addpoint (string s)
{
    int first_pos = 0;

    for (int j = 0; j < s.size(); j ++)
    {
        if (j + 1 < s.size() and s[j] == '-' and s[j + 1] == '>')
            first_pos = j + 2;
    }

    string tail = s.substr (first_pos);
    string head = s.substr (0, first_pos);
    string start = head + "." + tail;
    return start;
}
// 打印函数
void print (int sp, stack<int> sta,stack<string> stk, string input)
{
    cout << sp << "\t";
    string num = "";

    while(sta.size()) num = to_string(sta.top()) + num, sta.pop();
    string st = "";

    while (stk.size()) st = stk.top() + st, stk.pop();
    cout << num << '\t';
    cout << st << '\t';
    cout << input << endl;

}
// 判断两个map是否相等
bool check (map<ind, int> x, map<ind, int> y)
{
    if (x.size() != y.size()) return false;

    bool no = true;

    for (auto p : x)
    {
        if (!y.count (p.first))
            no = false;
    }

    return no;
}
// 扩展当前项目集
void get_CLO (int id)
{
    bool has_add = true;

    while (has_add)
    {
        has_add = false;

        for (auto c : Ip[id])
        {
            ind S = c.first;
            string a = "";
            int pos = 0;

            for (int i = 0; i < S.s.size(); i ++)
                if (S.s[i] == '.')
                {
                    a += S.s[i + 1];
                    pos = i + 1;
                }

            // a是.后的第一个符号
            // p 是后面的FIRST集
            if (!isVT (a))
            {
                set<string> p = get_FIRST_of (S.s.substr (pos + 1) + S.f);

                for (int i = 0; i < n ; i ++)
                {
                    string pa = "";
                    pa = s[i][0];

                    if (pa == a)
                    {
                        for (auto x : p)
                        {
                            ind tep = {addpoint (s[i]), x};

                            if (!Ip[id].count (tep))
                            {
                                Ip[id][tep] = cnt_ip[id] ++;
                                has_add = true;
                            }
                        }
                    }
                }
            }
        }
    }

}
// 扩展当前项目集并且寻找边连接并发展其他项目集
void get_CLO_tree (int id)
{
    bool has_add = true;

    while (has_add)
    {
        has_add = false;

        for (auto c : I[id])
        {
            ind S = c.first;
            string a = "";
            int pos = 0;

            for (int i = 0; i < S.s.size(); i ++)
                if (S.s[i] == '.')
                {
                    a += S.s[i + 1];
                    pos = i + 1;
                }

            if (!isVT (a))
            {
                set<string> p = get_FIRST_of (S.s.substr (pos + 1) + S.f);

                for (int i = 0; i < n ; i ++)
                {
                    string pa = "";
                    pa = s[i][0];

                    if (pa == a)
                    {
                        for (auto x : p)
                        {
                            ind tep = {addpoint (s[i]), x};

                            if (!I[id].count (tep))
                            {
                                I[id][tep] = cnt_i[id] ++;
                                has_add = true;
                            }
                        }
                    }
                }
            }
        }
    }


    // 给当前的项目集 连边
    int idd = index;
    map<PIS, int> ne;
    map<int, string> ha;

    for (auto x : I[id])
    {
        int point_pos = get_point (x.first.s);

        if (point_pos != x.first.s.size() - 1)
        {
            string a = "";
            a += x.first.s[point_pos + 1];
            if (!ne.count ({id, a}))
            {
                idd ++;
                ne[ {id, a}] = idd ;
                ha[idd] = a;
                ind y = x.first;
                swap (y.s[point_pos], y.s[point_pos + 1]);
                Ip[idd][y] = cnt_ip[idd] ++;
            }
            else
            {
                int idp = ne[ {id, a}];
                ind y = x.first;
                swap (y.s[point_pos], y.s[point_pos + 1]);
                Ip[idp][y] = cnt_ip[idp] ++;
            }
        }
    }

    // 对当前新建的项目集开始扩展
    // 扩展完之后比对是否出现过一样的项目集，有则删去，没有则新增这个项目集
    int last = index;
    for (int i = last + 1 ; i <= idd; i ++)
    {
        get_CLO (i);
        bool ok = true;

        for (int j = 0 ; j < index; j ++)
        {
            if (check (Ip[i], I[j]))
            {
                GO[ {id, ha[i]}] = j;

                ok = false;
            }
        }

        if (ok)
        {
            GO[ {id, ha[i]}] = index;
            I[index] = Ip[i];
            index ++;
        }
        Ip[i].clear();
        cnt_ip[i] = 0;
    }

    // 从初态向外扩展
    if(id == 0)
    {
        for (int i = id + 1 ; i < index ; i ++)
            get_CLO_tree (i);
    }

}
// 得到所有的项目集
void get_CLOSURE (ind S)
{
    index = 0;
    I[index][S] = cnt_i[index] ++;
    get_CLO_tree (index ++);
}
// 归约
void Reduce()
{
    stack<int> sta;
    stack<string> stk;

//	string input = "abab#";
    string input = "i+i*i#";
    int step = 0;
    sta.push(0);
    stk.push("#");

    bool over = false;
    print(++ step, sta, stk, input);
    while (!over)
    {
        // 取状态栈和符号栈的栈顶元素
        string now_s = stk.top();
        int now_n = sta.top();

        // 取剩余输入串的首字符
        string a = "";
        a = input[0];


        // 直接查表得到当前ACTION
        string action = ACTION[{now_n, a}];

        // s动作  移入
        if(action[0] == 's')
        {
            int st = stoi(action.substr(1));
            sta.push(st);
            input = input.substr(1);
            stk.push(a);
            print(++ step , sta, stk, input);
        }
        else if(action[0] == 'r') // r动作，归约并移入
        {

            // 归约
            int st = stoi(action.substr(1));

            string Str = s[st];

            int first_pos = 0;
            string now_vn = "";

            for (int j = 0; j < Str.size(); j ++)
            {
                if (j == 0) now_vn += Str[j];

                if (j + 1 < Str.size() and Str[j] == '-' and Str[j + 1] == '>')
                    first_pos = j + 2;
            }

            string ans = Str.substr(first_pos);

            for(int i = ans.size() - 1 ; i >= 0; i --)
            {
                string a = "";
                a = ans[i];
                if(a == stk.top())
                    stk.pop(),sta.pop();
            }

            // 移入
            stk.push(now_vn);

            string la = "";
            la = input[0];
            int action_n = GOTO[{sta.top(), stk.top()}];

            sta.push(action_n);
            print(++ step, sta, stk, input);


        }
        else if(action == "acc") // 成功匹配
        {
            over = true;
            cout << "Accept!" << endl;
        }
        else // 匹配失败
        {
            over = true;
            cout << "Error!" << endl;
        }

    }
}
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_ST_clicked()
{
    // 文法个数的设置
    n = 7;
    //	n = 4;

    // 获得全部终结符和非终结符集合
    for (int i = 0; i < n; i ++)
    {
//		cout << s[i] << endl;
        for (int j = 0; j < s[i].size(); j ++)
        {
            if (j + 1 < s[i].size() and s[i][j] == '-' and s[i][j + 1] == '>')
            {
                j ++;
                continue;
            }

            string d = "";
            d += s[i][j];

            if (isVT (d))
                get_VT (d);
            else get_VN (d);
        }
    }


    get_VT ("#");

//	cout << "VT:" << endl;
//	for(auto x : VT) cout << x.first << endl;
//	cout << "VN:" << endl;
//	for(auto x : VN) cout << x.first << endl;
//  cout <<"cnt is "<< cnt_vn << endl;
    // 求出所有非终结符的FIRST集合
    get_FIRST();
    ind S = {addpoint (s[0]), "#"};
    get_CLOSURE (S);
    for (int i = 0; i < index ; i ++)
    {
//		cout << "index " << i << endl;
//		for (auto x : I[i])
//		{
//			auto c = x.first;
//			cout << c.s << " ," << c.f << " <----> ";
//		}
//
//		cout <<"num is " << I[i].size() <<  endl;
//		cout << "GO " << i << endl;
        for (int j = 0 ; j < cnt_vn; j ++)
        {
            auto c = num_to_VN (j);

            if (!GO.count ({i, c})) GO[ {i, c}] = -1;
//			cout << c << ' ' << GO[{i, c}] << ' ';
        }

        for (int j = 0; j < cnt_vt; j ++)
        {
            auto c = num_to_VT (j);

            if (!GO.count ({i, c})) GO[ {i, c}] = -1;
//			cout << c << ' ' << GO[{i, c}] << ' ';
        }

//		cout << endl;
    }

    // 构建ACTION 和 GOTO
    get_tab();

//	for (int i = 0 ; i < cnt_vn; i ++)
//		for (int j = 0; j < index ; j ++)
//		{
//			cout << j << ' ' << num_to_VN (i) << ' ' << GOTO[ {j, num_to_VN (i) }] << endl;
//		}
//
//	for (int i = 0 ; i < cnt_vt; i ++)
//		for (int j = 0; j < index ; j ++)
//		{
//			cout << j << ' ' << num_to_VT (i) << ' ' << ACTION[ {j, num_to_VT (i) }] << endl;
//		}
//


    // 归约程序
//	Reduce();

    qDebug() << "i" << endl;
    ui->CWidget->setText("");
    for(int i = 0 ; i < n ; i ++)
    {
        QString scon = QString::fromStdString(s[i]);
        ui->CWidget->append(scon);
        qDebug() << i << endl;
    }
}
