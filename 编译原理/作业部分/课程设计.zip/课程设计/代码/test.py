import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter.scrolledtext import ScrolledText

# 定义一个类，用于存储文法规则
class Info:
    def __init__(self, left):
        self.left = left  # 左部非终结符
        self.right = []  # 右部产生式
        self.first = set()  # FirstVT集合
        self.last = set()  # LastVT集合

# 语义子程序
class SemanticActions:
    def __init__(self):
        self.temp_counter = 0
        self.symbol_table = {}

    def new_temp(self):
        temp = f't{self.temp_counter}'
        self.temp_counter += 1
        return temp

    def lookup(self, id_name):
        return self.symbol_table.get(id_name)

    def emit(self, code):
        print(code)

    def E_E1_plus_T(self, E, E1, T):
        E['place'] = self.new_temp()
        self.emit(f"{E['place']} := {E1['place']} + {T['place']}")

    def E_E1_minus_T(self, E, E1, T):
        E['place'] = self.new_temp()
        self.emit(f"{E['place']} := {E1['place']} - {T['place']}")

    def E_T(self, E, T):
        E['place'] = self.new_temp()
        self.emit(f"{E['place']} := uminus {T['place']}")

    def E_i(self, E, id_name):
        p = self.lookup(id_name)
        if p is not None:
            E['place'] = p
        else:
            raise ValueError(f"Error: Identifier '{id_name}' not found")

    def T_T1_mul_F(self, T, T1, F):
        T['place'] = self.new_temp()
        self.emit(f"{T['place']} := {T1['place']} * {F['place']}")

    def T_T1_div_F(self, T, T1, F):
        T['place'] = self.new_temp()
        self.emit(f"{T['place']} := {T1['place']} / {F['place']}")

    def T_F(self, T, F):
        T['place'] = self.new_temp()
        self.emit(f"{T['place']} := uminus {F['place']}")

    def F_E(self, F, E):
        F['place'] = E['place']

    def F_i(self, F, id_name):
        p = self.lookup(id_name)
        if p is not None:
            F['place'] = p
        else:
            raise ValueError(f"Error: Identifier '{id_name}' not found")

# 全局变量用于存储文法规则的列表
lang = []

# 定义一个全局的算符优先矩阵，初始化为9x9的矩阵，每个元素初始为'n'
mtr = [['n'] * 9 for _ in range(9)]

# 从文件读取文法规则，并解析成内部结构
def get_grammar_from_file(filename):
    """
    从文件中读取文法规则，并解析为内部结构
    """
    lang.clear()  # 清空现有的文法规则
    try:
        with open(filename, 'r') as file:
            lines = file.readlines()
        for line in lines:
            left, rights = line.strip().split('->')
            temp = Info(left)
            temp.right.extend(rights.split('|'))
            lang.append(temp)
    except FileNotFoundError:
        print(f"文件 {filename} 未找到")
    except Exception as e:
        print(f"读取文件时发生错误: {e}")


# 计算文法规则中的FirstVT和LastVT集合
def get_first_last():
    # 首先计算 FirstVT 集合终结符
    for info in lang:
        for right in info.right:
            if right[0] < 'A' or right[0] > 'Z':  # 如果右部第一个符号是终结符，即P->a...
                info.first.add(right[0])
            elif len(right) >= 2 and (right[1] < 'A' or right[1] > 'Z'):  # 如果右部第二个符号是终结符，即P->Qa...
                info.first.add(right[1])

    # 遍历形如P->Q...的产生式，直到不再变化
    sign = 0
    while sign == 0:
        sign = 1  # 假设集合不再变化
        for info in lang:
            for right in info.right:
                if 'A' <= right[0] <= 'Z':  # 如果产生式的右部第一个是非终结符，即P->Q....
                    for k in lang:
                        if k.left == right[0]:  # 找到该非终结符的产生式
                            for ch in k.first:  # 将该非终结符的 FirstVT 集合添加到当前符号的 FirstVT 集合中
                                if ch not in info.first:
                                    info.first.add(ch)
                                    sign = 0  # 如果集合发生变化，继续迭代

    # 首先计算 LastVT 集合终结符
    for info in lang:
        for right in info.right:
            if (right[len(right) - 1] < 'A' or right[len(right) - 1] > 'Z'):  # 如果右部最后一个符号且是终结符,即P->...a
                info.last.add(right[len(right) - 1])
            elif len(right) >= 2 and (
                    right[len(right) - 2] < 'A' or right[len(right) - 2] > 'Z'):  # 如果右部倒数第二个符号是终结符,即P->...aQ
                info.last.add(right[len(right) - 2])

    # 遍历形如P->...Q的产生式，直到不再变化
    sign = 0
    while sign == 0:
        sign = 1  # 假设集合不再变化
        for info in lang:
            for right in info.right:
                if 'A' <= right[len(right) - 1] <= 'Z':  # 如果产生式的右部最后一个字符是非终结符,即P->...Q
                    for k in lang:
                        if k.left == right[len(right) - 1]:  # 找到该非终结符的产生式
                            for ch in k.last:  # 将该非终结符的 LastVT 集合添加到当前符号的 LastVT 集合中
                                if ch not in info.last:
                                    info.last.add(ch)
                                    sign = 0  # 如果集合发生变化，继续迭代



# 计算算符优先矩阵
def get_matrix():

    # 获取所有的终结符
    terminal_symbols = set()
    for info in lang:
        terminal_symbols.update(info.first)
        terminal_symbols.update(info.last)

    terminal_symbols.add('#')

    terminal = ''.join(sorted(terminal_symbols, key=lambda x: '+-*/()i#'.index(x)))
    # terminal = ''.join(terminal_symbols)
    print(terminal)

    #算符优先矩阵
    global mtr
    mtr = [['n'] * (len(terminal) + 1) for _ in range(len(terminal) + 1)]

    # 初始化算符优先矩阵的第一行和第一列
    for i in range(1, len(terminal)+1):
        mtr[i][0] = terminal[i - 1]
        mtr[0][i] = terminal[i - 1]

    # 构造优先表
    for info in lang:
        for right in info.right:
            for i in range(len(right) - 1):
                X_i = right[i]
                X_i1 = right[i + 1]

                # X_i 和 X_i+1 均为终结符
                if X_i in terminal and X_i1 in terminal:
                    mtr[terminal.index(X_i) + 1][terminal.index(X_i1) + 1] = '='

                # i ≤ n - 2 且 X_i 和 X_i+2 都为终结符
                if i <= len(right) - 3 and X_i in terminal and right[i + 2] in terminal and X_i1 not in terminal:
                    mtr[terminal.index(X_i) + 1][terminal.index(right[i + 2]) + 1] = '='

                # X_i 为终结符而 X_i1 为非终结符
                if X_i in terminal and X_i1 not in terminal:
                    # 获取 X_i1 的 first 集合
                    first_set = None
                    for info2 in lang:
                        if info2.left == X_i1:
                            first_set = info2.first
                            break

                    # 设置优先关系
                    if first_set:
                        for a in first_set:
                            mtr[terminal.index(X_i) + 1][terminal.index(a) + 1] = '<'

                # X_i 为非终结符而 X_i1 为终结符
                if X_i not in terminal and X_i1 in terminal:
                    # 获取 X_i 的 last 集合
                    last_set = None
                    for info2 in lang:
                        if info2.left == X_i:
                            last_set = info2.last
                            break

                    # 设置优先关系
                    if last_set:
                        for a in last_set:
                            mtr[terminal.index(a) + 1][terminal.index(X_i1) + 1] = '>'

    # 特殊处理起始和终止符号
    # 获取起始符号
    start_symbol = lang[0].left

    # 获取起始符号的 first 集合
    first_set = None
    for info in lang:
        if info.left == start_symbol:
            first_set = info.first
            break

    # 设置 # 和 first 集合中的符号之间的优先关系为 <
    if first_set:
        for ch in first_set:
            mtr[terminal.index('#') + 1][terminal.index(ch) + 1] = '<'

    # 获取起始符号的 last 集合
    last_set = None
    for info in lang:
        if info.left == start_symbol:
            last_set = info.last
            break

    # 设置 last 集合中的符号和 # 之间的优先关系为 >
    if last_set:
        for ch in last_set:
            mtr[terminal.index(ch) + 1][terminal.index('#') + 1] = '>'

    # 设置 # 和 # 之间的优先关系为 =
    mtr[terminal.index('#') + 1][terminal.index('#') + 1] = '='


# 转换表达式为三元式
def start(expression):
    """
    将算术表达式转换为三元式
    """
    data_stack = []  # 数据栈
    op_stack = ['#']  # 操作符栈，初始化时包含终止符#
    now = 'n'  # 当前操作符
    j = 0  # 用于编号
    output = []  # 存储输出结果

    for i, ch in enumerate(expression):
        sign = 0  # 标记是否为操作符
        if ch.isdigit():  # 处理数字
            number = 0
            while i < len(expression) and expression[i].isdigit():
                number = number * 10 + int(expression[i])
                i += 1
            data_stack.append(str(number))
            i -= 1
        else:
            op_stack.append(ch)
            sign = 1

        if now != 'n' and sign == 1:
            while cmp(now, op_stack[-1]) == 1:  # 如果当前操作符优先级高于栈顶操作符
                j += 1
                avg1 = data_stack.pop()
                avg2 = data_stack.pop()
                num = f"({j})"
                output.append(f"{num}  ( {now},\t{avg2},\t{avg1} )")
                data_stack.append(num)
                op_stack.pop()
                op_stack.pop()
                if op_stack:
                    now = op_stack[-1]
                else:
                    now = 'n'
                op_stack.append(ch)

            if cmp(now, op_stack[-1]) == 0:  # 如果当前操作符优先级等于栈顶操作符
                op_stack.pop()
                op_stack.pop()
                if op_stack:
                    now = op_stack[-1]
                else:
                    break
        else:
            if op_stack:
                now = op_stack[-1]

    while op_stack and op_stack[-1] != '#':  # 处理剩余操作符
        j += 1
        avg1 = data_stack.pop()
        avg2 = data_stack.pop()
        num = f"({j})"
        output.append(f"{num}  ( {now},\t{avg2},\t{avg1} )")
        data_stack.append(num)
        op_stack.pop()
        op_stack.pop()
        if op_stack:
            now = op_stack[-1]

    return output

# 比较操作符优先级，返回1表示a>b，0表示a=b，-1表示a<b，2表示错误
def cmp(a, b):
    """
    比较两个操作符的优先级
    """
    for i in range(1, 9):
        if mtr[i][0] == a:
            for j in range(1, 9):
                if mtr[0][j] == b:
                    if mtr[i][j] == '>':
                        return 1
                    elif mtr[i][j] == '=':
                        return 0
                    elif mtr[i][j] == '<':
                        return -1
    return 2

# 定义主界面类
class ExpressionConverterApp:
    def __init__(self, root):
        """
        初始化主界面
        """
        self.root = root
        self.root.title("算术表达式转换成三元式")

        # 使用一个框架来添加滚动条
        main_frame = tk.Frame(root)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # 添加滚动条
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(
                scrollregion=canvas.bbox("all")
            )
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="n")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # 上部信息
        tk.Label(scrollable_frame, text="编译原理课程设计：算术表达式转换成三元式", font=("宋体", 18)).pack(pady=10)
        tk.Label(scrollable_frame, text="By：许航睿", font=("宋体", 14)).pack(pady=5)

        # 显示文法规则的文本框
        self.grammar_display = ScrolledText(scrollable_frame, width=80, height=10, font=("宋体", 12), state=tk.DISABLED)
        self.grammar_display.pack(pady=10)

        # 文件读入文法按钮
        self.load_grammar_button = tk.Button(scrollable_frame, text="文件读入文法", command=self.load_grammar,
                                             font=("宋体", 12))
        self.load_grammar_button.pack(pady=5)

        # 显示FirstVT和LastVT集合的文本框
        self.first_last_display = ScrolledText(scrollable_frame, width=80, height=10, font=("宋体", 12),
                                               state=tk.DISABLED)
        self.first_last_display.pack(pady=10)

        # 展示FirstVT和LastVT按钮
        self.first_last_button = tk.Button(scrollable_frame, text="展示FirstVT和LastVT", command=self.show_first_last,
                                           font=("宋体", 12))
        self.first_last_button.pack(pady=5)

        # 显示算符优先矩阵的文本框
        self.matrix_display = ScrolledText(scrollable_frame, width=80, height=10, font=("宋体", 12), state=tk.DISABLED)
        self.matrix_display.pack(pady=10)

        # 展示算符优先矩阵按钮
        self.matrix_button = tk.Button(scrollable_frame, text="展示算符优先矩阵", command=self.show_matrix,
                                       font=("宋体", 12))
        self.matrix_button.pack(pady=5)

        # 输入算术表达式的标签和输入框
        tk.Label(scrollable_frame, text="输入算术表达式：", font=("宋体", 14)).pack(pady=10)
        self.expression_entry = tk.Entry(scrollable_frame, font=("宋体", 14), width=50)
        self.expression_entry.pack(pady=5)

        # 显示转换结果的文本框
        self.result_display = ScrolledText(scrollable_frame, width=80, height=10, font=("宋体", 12), state=tk.DISABLED)
        self.result_display.pack(pady=10)

        # 转换成三元式按钮
        self.convert_button = tk.Button(scrollable_frame, text="转换成三元式", command=self.convert_expression,
                                        font=("宋体", 12))
        self.convert_button.pack(pady=5)

        # 保存结果到文件按钮
        self.save_button = tk.Button(scrollable_frame, text="保存结果到文件", command=self.save_results,
                                     font=("宋体", 12))
        self.save_button.pack(pady=10)

        # 绑定鼠标滚轮事件
        self.bind_scroll_events(canvas)

    # 绑定鼠标滚轮事件
    def bind_scroll_events(self, canvas):
        """
        绑定鼠标滚轮事件
        """
        def on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", on_mousewheel)

    # 加载文法文件
    def load_grammar(self):
        """
        从文件中加载文法规则
        """
        filename = filedialog.askopenfilename(title="选择文法文件", filetypes=[("Text files", "*.txt")])
        if filename:
            get_grammar_from_file(filename)
            self.grammar_display.config(state=tk.NORMAL)
            self.grammar_display.delete(1.0, tk.END)
            for info in lang:
                for right in info.right:
                    self.grammar_display.insert(tk.END, f"{info.left} --> {right}\n")
            self.grammar_display.config(state=tk.DISABLED)

    # 展示FirstVT和LastVT集合
    def show_first_last(self):
        """
        计算并展示FirstVT和LastVT集合
        """
        get_first_last()
        first_vt_dict = {}
        last_vt_dict = {}

        for info in lang:
            if info.left not in first_vt_dict:
                first_vt_dict[info.left] = info.first
            else:
                first_vt_dict[info.left] |= info.first

            if info.left not in last_vt_dict:
                last_vt_dict[info.left] = info.last
            else:
                last_vt_dict[info.left] |= info.last

        self.first_last_display.config(state=tk.NORMAL)
        self.first_last_display.delete(1.0, tk.END)

        self.first_last_display.insert(tk.END, "FirstVT:\n")
        for key, value in first_vt_dict.items():
            first_vt = '  '.join(value)
            self.first_last_display.insert(tk.END, f"{key} : {first_vt}\n")

        self.first_last_display.insert(tk.END, "\nLastVT:\n")
        for key, value in last_vt_dict.items():
            last_vt = '  '.join(value)
            self.first_last_display.insert(tk.END, f"{key} : {last_vt}\n")

        self.first_last_display.config(state=tk.DISABLED)

    # 展示算符优先矩阵
    def show_matrix(self):
        """
        计算并展示算符优先矩阵
        """
        get_matrix()
        self.matrix_display.config(state=tk.NORMAL)
        self.matrix_display.delete(1.0, tk.END)
        for row in mtr:
            self.matrix_display.insert(tk.END, '\t'.join([c if c != 'n' else '' for c in row]) + '\n')
        self.matrix_display.config(state=tk.DISABLED)

    # 转换表达式并显示三元式
    def convert_expression(self):
        """
        将输入的算术表达式转换为三元式并显示
        """
        expression = self.expression_entry.get()
        if expression:
            result = start(expression + '#')
            self.result_display.config(state=tk.NORMAL)
            self.result_display.delete(1.0, tk.END)
            for line in result:
                self.result_display.insert(tk.END, line + '\n')
            self.result_display.config(state=tk.DISABLED)
        else:
            messagebox.showwarning("输入错误", "请输入算术表达式")

    # 保存结果到文件
    def save_results(self):
        """
        保存文法规则、FirstVT和LastVT集合、算符优先矩阵和三元式结果到文件
        """
        filename = filedialog.asksaveasfilename(defaultextension=".txt",
                                                filetypes=[("Text files", "*.txt")],
                                                title="保存结果到文件")
        if filename:
            try:
                with open(filename, 'w') as file:
                    # 保存文法规则
                    file.write("文法规则:\n")
                    for info in lang:
                        for right in info.right:
                            file.write(f"{info.left} --> {right}\n")

                    # 保存FirstVT和LastVT集合
                    file.write("\nFirstVT:\n")
                    first_vt_dict = {}
                    last_vt_dict = {}

                    for info in lang:
                        if info.left not in first_vt_dict:
                            first_vt_dict[info.left] = info.first
                        else:
                            first_vt_dict[info.left] |= info.first

                        if info.left not in last_vt_dict:
                            last_vt_dict[info.left] = info.last
                        else:
                            last_vt_dict[info.left] |= info.last

                    for key, value in first_vt_dict.items():
                        first_vt = '  '.join(value)
                        file.write(f"{key} : {first_vt}\n")

                    file.write("\nLastVT:\n")
                    for key, value in last_vt_dict.items():
                        last_vt = '  '.join(value)
                        file.write(f"{key} : {last_vt}\n")

                    # 保存算符优先矩阵
                    file.write("\n算符优先矩阵:\n")
                    for row in mtr:
                        file.write('\t'.join([c if c != 'n' else '' for c in row]) + '\n')

                    # 保存三元式
                    file.write("\n三元式:\n")
                    expression = self.expression_entry.get()
                    if expression:
                        result = start(expression + '#')
                        for line in result:
                            file.write(line + '\n')
                    else:
                        file.write("无三元式输出\n")
                messagebox.showinfo("保存成功", "结果已成功保存到文件")
            except Exception as e:
                messagebox.showerror("保存失败", f"保存文件时发生错误: {e}")

# 程序入口，创建主窗口并运行应用
if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("680x800")  # 设置主窗口初始大小
    app = ExpressionConverterApp(root)
    root.mainloop()
